var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../apps/slk-bi/src/messages/catalog.ts
var SUPERVISOR = ["supervisor"];
var CHECKER = ["checker"];
var CONTROL = ["supervisor", "checker"];
var WORKER = ["worker"];
var OVERWATCHER = ["overwatcher"];
var TECHNICAL = ["supervisor", "checker", "worker"];
var ALL = ["supervisor", "checker", "worker", "overwatcher"];
var EVENT_SEEDS = [
  ["RUN_INITIALIZED", "Run \u5DF2\u5EFA\u7ACB", SUPERVISOR],
  ["RUN_PAUSE_REQUESTED", "Run \u6682\u505C\u5DF2\u8BF7\u6C42", SUPERVISOR],
  ["RUN_PAUSED", "Run \u5DF2\u6682\u505C", SUPERVISOR],
  ["RUN_RESUMED", "Run \u5DF2\u7EE7\u7EED", SUPERVISOR],
  ["OVERWATCHER_BOUND", "Overwatcher \u5DF2\u7ED1\u5B9A", SUPERVISOR],
  ["PLAN_REVISED", "\u8BA1\u5212\u5DF2\u4FEE\u8BA2", SUPERVISOR],
  ["ROLE_REGISTERED", "\u89D2\u8272\u5DF2\u767B\u8BB0", ["supervisor", "checker"]],
  ["ROLE_REPLACED", "\u89D2\u8272\u5DF2\u66FF\u6362", ["supervisor", "checker"]],
  ["MODEL_CHANGED", "\u6A21\u578B\u7ED1\u5B9A\u5DF2\u53D8\u66F4", SUPERVISOR],
  ["SESSION_REBOUND", "Session \u5DF2\u91CD\u65B0\u7ED1\u5B9A", CONTROL],
  ["OVERWATCHER_TURN_RESUMED", "Overwatcher turn \u5DF2\u6062\u590D", SUPERVISOR],
  ["EXEMPTION_GRANTED", "\u8C41\u514D\u5DF2\u6279\u51C6", SUPERVISOR],
  ["D2_STARTED", "D2 \u5DF2\u5F00\u59CB", SUPERVISOR],
  ["D2_PASSED", "D2 \u5DF2\u901A\u8FC7", SUPERVISOR],
  ["D2_FAILED", "D2 \u672A\u901A\u8FC7", SUPERVISOR],
  ["RUN_SUPERSEDED", "Run \u5DF2\u88AB\u66FF\u4EE3", SUPERVISOR],
  ["RUN_ABANDONED", "Run \u5DF2\u5E9F\u9664", SUPERVISOR],
  ["RUN_CLOSED", "Run \u5DF2\u5173\u95ED", SUPERVISOR],
  ["CELL_DISPATCHED", "CELL \u5DF2\u6D3E\u53D1", CHECKER],
  ["D1_STARTED", "D1 \u5DF2\u5F00\u59CB", CHECKER],
  ["D1_INCOMPLETE", "D1 \u4FE1\u606F\u4E0D\u5B8C\u6574", CHECKER],
  ["D1_PASSED", "D1 \u5DF2\u901A\u8FC7", CHECKER],
  ["D1_FAILED", "D1 \u672A\u901A\u8FC7", CHECKER],
  ["REWORK_REQUESTED", "\u8FD4\u5DE5\u5DF2\u8981\u6C42", SUPERVISOR],
  ["CELL_SPLIT", "CELL \u5DF2\u62C6\u5206", SUPERVISOR],
  ["CANDIDATE_FORWARDED", "\u5019\u9009\u5DF2\u8F6C\u4EA4", CHECKER],
  ["WORK_STARTED", "Worker \u5F00\u59CB\u5DE5\u4F5C", WORKER],
  ["WORK_PROGRESS", "Worker \u8BB0\u5F55\u8FDB\u5C55", WORKER],
  ["BLOCKER_REPORTED", "Worker \u62A5\u544A\u963B\u65AD", WORKER],
  ["CHANGE_RECORDED", "\u53D8\u66F4\u5DF2\u8BB0\u5F55", WORKER],
  ["D0_COMPLETED", "D0 \u5DF2\u5B8C\u6210", WORKER],
  ["CANDIDATE_SUBMITTED", "\u5019\u9009\u5DF2\u4EA4\u4ED8", WORKER],
  ["RESOURCE_CONTENDED", "\u8D44\u6E90\u53D1\u751F\u51B2\u7A81", TECHNICAL],
  ["RESOURCE_RECOVERED", "\u8D44\u6E90\u5DF2\u6062\u590D", TECHNICAL],
  ["EVIDENCE_REGISTERED", "\u8BC1\u636E\u5DF2\u767B\u8BB0", ALL],
  ["TOKEN_HANDED_OFF", "SLK TOKEN \u5DF2\u4EA4\u63A5", TECHNICAL],
  ["TRANSPORT_FAILED", "\u6D88\u606F\u6295\u9012\u5931\u8D25", TECHNICAL],
  ["TRANSPORT_STARTED", "\u63A5\u6536\u65B9\u539F\u751F\u5DE5\u4F5C\u5DF2\u542F\u52A8", TECHNICAL]
];
var SPECIALIZED_EVENT_SEEDS = [
  ["ROLE_CLOSED", "\u89D2\u8272\u5DF2\u5F52\u6863", SUPERVISOR]
];
var OBSERVATION_SEEDS = [
  ["DELIVERY_UNCONFIRMED", "\u6295\u9012\u672A\u786E\u8BA4", OVERWATCHER],
  ["DELIVERY_RETRYING", "\u6295\u9012\u6B63\u5728\u91CD\u8BD5", OVERWATCHER],
  ["ACTIVITY_UNPROVEN", "\u6D3B\u52A8\u65E0\u6CD5\u8BC1\u5B9E", OVERWATCHER],
  ["RECORD_CONFLICT", "\u8BB0\u5F55\u4E0E\u4E8B\u5B9E\u51B2\u7A81", OVERWATCHER],
  ["RECOVERY_ESCALATED", "\u6062\u590D\u5DF2\u5347\u7EA7", OVERWATCHER],
  ["PROJECTION_REFRESH_REQUESTED", "\u6295\u5F71\u5237\u65B0\u5DF2\u8BF7\u6C42", OVERWATCHER],
  ["OVERWATCHER_CLOSED", "Overwatcher \u5DF2\u5173\u95ED", OVERWATCHER],
  ["WORKER_COMPLETION_HANDOFF_MISSING", "Worker \u5B8C\u6210\u4EA4\u63A5\u7F3A\u5931", OVERWATCHER]
];
function entries(sourceKind, seeds) {
  return seeds.map(([message_type, label_zh, allowed_roles]) => ({
    source_kind: sourceKind,
    message_type,
    label_zh,
    allowed_roles: [...allowed_roles],
    notification_eligible: true
  }));
}
__name(entries, "entries");
var MESSAGE_CATALOG = Object.freeze([
  ...entries("EVENT", EVENT_SEEDS),
  ...entries("EVENT", SPECIALIZED_EVENT_SEEDS),
  ...entries("OW_OBSERVATION", OBSERVATION_SEEDS)
]);
function catalogKey(sourceKind, messageType) {
  return `${sourceKind}:${messageType}`;
}
__name(catalogKey, "catalogKey");
function catalogEntry(catalog, sourceKind, messageType) {
  return catalog.find(
    (entry) => entry.source_kind === sourceKind && entry.message_type === messageType
  );
}
__name(catalogEntry, "catalogEntry");

// ../apps/slk-bi/src/runPresentation.ts
function isArchivedSummary(run) {
  return run.archive_control !== "creator" && run.closure_state !== "open" || run.state === "archived" || Boolean(run.archived_at);
}
__name(isArchivedSummary, "isArchivedSummary");

// ../apps/slk-bi/src/version.ts
var BI_VERSION = "1.1.4";
var COMPATIBLE_BI_VERSIONS = ["1.1.0", "1.1.1", "1.1.2", "1.1.3", BI_VERSION];
function isCompatibleBiVersion(value) {
  return COMPATIBLE_BI_VERSIONS.some((version) => version === value);
}
__name(isCompatibleBiVersion, "isCompatibleBiVersion");

// ../apps/slk-bi/src/contracts.ts
function object(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error("SLK_BI_PROJECTION_INVALID");
  }
  return value;
}
__name(object, "object");
function schema(value, expected) {
  const projection = object(value);
  if (projection.schema_version !== expected) {
    throw new Error(`SLK_BI_SCHEMA_UNSUPPORTED:${String(projection.schema_version)}`);
  }
  return projection;
}
__name(schema, "schema");
function collection(projection, key) {
  if (!Array.isArray(projection[key])) throw new Error("SLK_BI_PROJECTION_INVALID");
}
__name(collection, "collection");
function parseRunProjection(value) {
  const projection = schema(value, "slk.bi.run/v1");
  object(projection.summary);
  object(projection.administrative_snapshot);
  if (projection.source_record !== void 0) {
    const source = object(projection.source_record);
    for (const key of ["creator_supervisor_id", "revision", "status_text"]) {
      if (typeof source[key] !== "string") throw new Error("SLK_BI_SOURCE_RECORD_INVALID");
    }
    if (source.kind !== "markdown" || !source.creator_supervisor_id || !source.revision || typeof source.timing_available !== "boolean") {
      throw new Error("SLK_BI_SOURCE_RECORD_INVALID");
    }
    if (source.progress !== null) {
      const progress = object(source.progress);
      if (!Number.isSafeInteger(progress.passed) || !Number.isSafeInteger(progress.total) || Number(progress.passed) < 0 || Number(progress.total) < Number(progress.passed)) throw new Error("SLK_BI_SOURCE_PROGRESS_INVALID");
    }
    if (source.archived_by !== void 0 && source.archived_by !== source.creator_supervisor_id) throw new Error("SLK_BI_ARCHIVE_CREATOR_MISMATCH");
  }
  for (const key of ["go_nodes", "roles", "plan_revisions", "events", "token_history", "evidence", "overwatch_cycles", "overwatcher_native_status_receipts", "overwatcher_incident_transitions", "overwatcher_binding_transitions", "operational_observations", "reconciliation_receipts", "method_adoption_receipts"]) {
    collection(projection, key);
  }
  return projection;
}
__name(parseRunProjection, "parseRunProjection");

// ../apps/slk-bi/src/webbi/contracts.ts
function object2(value, code) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(code);
  return value;
}
__name(object2, "object");
function exactKeys(value, expected, code) {
  const actual = Object.keys(value).sort();
  const wanted = [...expected].sort();
  if (actual.length !== wanted.length || actual.some((key, index) => key !== wanted[index])) {
    throw new Error(code);
  }
}
__name(exactKeys, "exactKeys");
function text(value, max, code) {
  if (typeof value !== "string" || !value.trim() || value.length > max) throw new Error(code);
  return value;
}
__name(text, "text");
function optionalText(value, max, code) {
  if (value === void 0 || value === null || value === "") return void 0;
  return text(value, max, code);
}
__name(optionalText, "optionalText");
function iso(value, code) {
  const result = text(value, 64, code);
  const timestamp = Date.parse(result);
  if (Number.isNaN(timestamp)) throw new Error(code);
  return new Date(timestamp).toISOString();
}
__name(iso, "iso");
function parseMessage(value, runId, catalog) {
  const raw = object2(value, "SLK_WEBBI_MESSAGE_INVALID");
  exactKeys(raw, [
    "message_id",
    "run_id",
    "source_kind",
    "source_id",
    "message_type",
    "label_zh",
    "author_role",
    "author_identity_ref",
    "go_id",
    "cell_id",
    "attempt",
    "occurred_at"
  ], "SLK_WEBBI_MESSAGE_INVALID");
  const sourceKind = text(raw.source_kind, 32, "SLK_WEBBI_MESSAGE_INVALID");
  if (sourceKind !== "EVENT" && sourceKind !== "OW_OBSERVATION") {
    throw new Error("SLK_WEBBI_MESSAGE_TYPE_INVALID");
  }
  const messageType = text(raw.message_type, 96, "SLK_WEBBI_MESSAGE_TYPE_INVALID");
  const entry = catalogEntry(catalog, sourceKind, messageType);
  if (!entry) throw new Error("SLK_WEBBI_MESSAGE_TYPE_INVALID");
  const role = text(raw.author_role, 32, "SLK_WEBBI_MESSAGE_ROLE_INVALID");
  if (!entry.allowed_roles.includes(role)) throw new Error("SLK_WEBBI_MESSAGE_ROLE_INVALID");
  if (raw.run_id !== runId) throw new Error("SLK_WEBBI_MESSAGE_SCOPE_INVALID");
  if (raw.label_zh !== entry.label_zh) throw new Error("SLK_WEBBI_MESSAGE_LABEL_INVALID");
  const messageId = text(raw.message_id, 196, "SLK_WEBBI_MESSAGE_INVALID");
  const sourceId = text(raw.source_id, 160, "SLK_WEBBI_MESSAGE_INVALID");
  if (messageId !== `${sourceKind}:${sourceId}`) throw new Error("SLK_WEBBI_MESSAGE_ID_INVALID");
  const attempt = raw.attempt;
  if (attempt !== null && (!Number.isSafeInteger(attempt) || Number(attempt) < 1)) {
    throw new Error("SLK_WEBBI_MESSAGE_SCOPE_INVALID");
  }
  return {
    message_id: messageId,
    run_id: runId,
    source_kind: sourceKind,
    source_id: sourceId,
    message_type: messageType,
    label_zh: entry.label_zh,
    author_role: role,
    author_identity_ref: text(raw.author_identity_ref, 160, "SLK_WEBBI_MESSAGE_INVALID"),
    go_id: raw.go_id === null ? null : text(raw.go_id, 96, "SLK_WEBBI_MESSAGE_SCOPE_INVALID"),
    cell_id: raw.cell_id === null ? null : text(raw.cell_id, 96, "SLK_WEBBI_MESSAGE_SCOPE_INVALID"),
    attempt,
    occurred_at: iso(raw.occurred_at, "SLK_WEBBI_MESSAGE_INVALID")
  };
}
__name(parseMessage, "parseMessage");
function parseUploadEnvelope(value, catalog) {
  const raw = object2(value, "SLK_WEBBI_UPLOAD_INVALID");
  exactKeys(
    raw,
    ["schema_version", "bi_version", "upload_id", "generated_at", "device", "runs"],
    "SLK_WEBBI_UPLOAD_INVALID"
  );
  if (raw.schema_version !== "slk.bi.upload/v1" || !isCompatibleBiVersion(raw.bi_version)) {
    throw new Error("SLK_WEBBI_UPLOAD_VERSION_UNSUPPORTED");
  }
  const deviceRaw = object2(raw.device, "SLK_WEBBI_DEVICE_INVALID");
  exactKeys(deviceRaw, ["device_id", "device_name"], "SLK_WEBBI_DEVICE_INVALID");
  const device = {
    device_id: text(deviceRaw.device_id, 128, "SLK_WEBBI_DEVICE_INVALID"),
    device_name: text(deviceRaw.device_name, 128, "SLK_WEBBI_DEVICE_INVALID")
  };
  if (!Array.isArray(raw.runs) || raw.runs.length > 500) {
    throw new Error("SLK_WEBBI_UPLOAD_INVALID");
  }
  const runs = raw.runs.map((item) => {
    const runRaw = object2(item, "SLK_WEBBI_UPLOAD_INVALID");
    exactKeys(runRaw, ["run", "messages"], "SLK_WEBBI_UPLOAD_INVALID");
    const run = parseRunProjection(runRaw.run);
    if (!Array.isArray(runRaw.messages) || runRaw.messages.length > 5e4) {
      throw new Error("SLK_WEBBI_UPLOAD_INVALID");
    }
    const messages = runRaw.messages.map((message) => parseMessage(message, run.run_id, catalog));
    if (new Set(messages.map((message) => message.message_id)).size !== messages.length) {
      throw new Error("SLK_WEBBI_MESSAGE_DUPLICATE");
    }
    return { run, messages };
  });
  if (new Set(runs.map(({ run }) => run.run_id)).size !== runs.length) {
    throw new Error("SLK_WEBBI_RUN_DUPLICATE");
  }
  return {
    schema_version: "slk.bi.upload/v1",
    bi_version: raw.bi_version,
    upload_id: text(raw.upload_id, 160, "SLK_WEBBI_UPLOAD_INVALID"),
    generated_at: iso(raw.generated_at, "SLK_WEBBI_UPLOAD_INVALID"),
    device,
    runs
  };
}
__name(parseUploadEnvelope, "parseUploadEnvelope");
function parseNotificationSettingsInput(value, catalog, options = {}) {
  const raw = object2(value, "SLK_WEBBI_NOTIFICATION_INVALID");
  const allowedKeys = [
    "enabled",
    "server_url",
    "topic",
    "auth_mode",
    "username",
    "secret",
    "selection_mode",
    "selected_message_types"
  ];
  if (Object.keys(raw).some((key) => !allowedKeys.includes(key))) {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  if (typeof raw.enabled !== "boolean") throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  const serverUrl = text(raw.server_url, 512, "SLK_WEBBI_NOTIFICATION_INVALID");
  let url;
  try {
    url = new URL(serverUrl);
  } catch {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  if (url.protocol !== "https:" && url.hostname !== "localhost") {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  const topic = text(raw.topic, 128, "SLK_WEBBI_NOTIFICATION_INVALID");
  if (!/^[A-Za-z0-9_-]+$/.test(topic)) throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  if (!["none", "token", "password"].includes(raw.auth_mode)) {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  if (!["all", "selected"].includes(raw.selection_mode)) {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  if (!Array.isArray(raw.selected_message_types)) {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  const validKeys = new Set(
    catalog.filter((entry) => entry.notification_eligible).map((entry) => catalogKey(entry.source_kind, entry.message_type))
  );
  const selected = raw.selected_message_types.map((item) => text(item, 160, "SLK_WEBBI_NOTIFICATION_TYPE_INVALID"));
  if (selected.some((item) => !validKeys.has(item))) {
    throw new Error("SLK_WEBBI_NOTIFICATION_TYPE_INVALID");
  }
  const authMode = raw.auth_mode;
  const username = optionalText(raw.username, 256, "SLK_WEBBI_NOTIFICATION_INVALID");
  const secret = optionalText(raw.secret, 4096, "SLK_WEBBI_NOTIFICATION_INVALID");
  if (authMode === "password" && !username) throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  if (authMode !== "none" && !secret && !options.allow_secret_reuse) {
    throw new Error("SLK_WEBBI_NOTIFICATION_INVALID");
  }
  return {
    enabled: raw.enabled,
    server_url: url.toString().replace(/\/$/, ""),
    topic,
    auth_mode: authMode,
    username: username ?? null,
    ...secret ? { secret } : {},
    selection_mode: raw.selection_mode,
    selected_message_types: [...new Set(selected)].sort()
  };
}
__name(parseNotificationSettingsInput, "parseNotificationSettingsInput");

// ../apps/slk-bi/src/webbi/notifications.ts
function canReuseNotificationSecret(current, input) {
  return current.auth_mode === input.auth_mode && current.server_url === input.server_url && (input.auth_mode !== "password" || current.username === input.username) && Boolean(current.encrypted_secret && current.secret_iv);
}
__name(canReuseNotificationSecret, "canReuseNotificationSecret");
function selectMessagesForNotification(messages, selection) {
  if (selection.selection_mode === "all") return [...messages];
  const selected = new Set(selection.selected_message_types);
  return messages.filter((message) => selected.has(catalogKey(message.source_kind, message.message_type)));
}
__name(selectMessagesForNotification, "selectMessagesForNotification");
function notificationKey(configVersion, deviceId, message) {
  return `${configVersion}:${deviceId}:${message.message_id}`;
}
__name(notificationKey, "notificationKey");
function toPublicNotificationSettings(settings) {
  return {
    enabled: settings.enabled,
    server_url: settings.server_url,
    topic: settings.topic,
    auth_mode: settings.auth_mode,
    username: settings.username,
    has_secret: Boolean(settings.encrypted_secret),
    selection_mode: settings.selection_mode,
    selected_message_types: [...settings.selected_message_types],
    config_version: settings.config_version
  };
}
__name(toPublicNotificationSettings, "toPublicNotificationSettings");

// ../apps/slk-bi/src/webbi/worker.ts
function isArchivedRun(run) {
  return isArchivedSummary(run.summary);
}
__name(isArchivedRun, "isArchivedRun");
function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff"
    }
  });
}
__name(json, "json");
function bearer(request) {
  const value = request.headers.get("authorization") ?? "";
  return value.startsWith("Bearer ") ? value.slice(7) : "";
}
__name(bearer, "bearer");
function bearerAuthorized(request, token) {
  return token.length >= 12 && bearer(request) === token;
}
__name(bearerAuthorized, "bearerAuthorized");
async function requestJson(request) {
  const length = Number(request.headers.get("content-length") ?? "0");
  if (Number.isFinite(length) && length > 10 * 1024 * 1024) {
    throw new Error("SLK_WEBBI_UPLOAD_TOO_LARGE");
  }
  const body = await request.text();
  if (new TextEncoder().encode(body).byteLength > 10 * 1024 * 1024) {
    throw new Error("SLK_WEBBI_UPLOAD_TOO_LARGE");
  }
  try {
    return JSON.parse(body);
  } catch {
    throw new Error("SLK_WEBBI_JSON_INVALID");
  }
}
__name(requestJson, "requestJson");
async function deliverNewMessages(dependencies, result) {
  if (result.bootstrap || result.inserted_messages.length === 0) return 0;
  const target = await dependencies.store.notificationTarget();
  if (!target?.settings.enabled) return 0;
  const selected = selectMessagesForNotification(
    result.inserted_messages.map(({ message }) => message),
    target.settings
  );
  const selectedIds = new Set(selected.map(({ message_id }) => message_id));
  let failures = 0;
  for (const record of result.inserted_messages) {
    if (!selectedIds.has(record.message.message_id)) continue;
    const key = notificationKey(
      target.settings.config_version,
      record.device.device_id,
      record.message
    );
    if (await dependencies.store.hasDelivery(key)) continue;
    try {
      await dependencies.notifier.send(target, record);
      await dependencies.store.recordDelivery(key, "sent");
    } catch (error) {
      failures += 1;
      await dependencies.store.recordDelivery(
        key,
        "failed",
        error instanceof Error ? error.message.slice(0, 256) : "notification failed"
      );
    }
  }
  return failures;
}
__name(deliverNewMessages, "deliverNewMessages");
function createWebBiHandler(dependencies) {
  return async (request) => {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/api/v1/uploads" && request.method === "POST") {
        if (!bearerAuthorized(request, dependencies.ingest_token)) {
          return json({ error: "SLK_WEBBI_UPLOAD_UNAUTHORIZED" }, 401);
        }
        const envelope = parseUploadEnvelope(await requestJson(request), dependencies.catalog);
        const result = await dependencies.store.ingest(envelope);
        const notification_failures = await deliverNewMessages(dependencies, result);
        return json({
          status: "accepted",
          upload_id: envelope.upload_id,
          inserted_message_count: result.inserted_messages.length,
          historical_bootstrap: result.bootstrap,
          notification_failures
        }, 202);
      }
      if (url.pathname === "/api/v1/catalog" && request.method === "GET") {
        return json({ schema_version: "slk.bi.message-catalog/v1", entries: dependencies.catalog });
      }
      if (url.pathname === "/api/v1/runs" && request.method === "GET") {
        const archive = url.searchParams.get("archive") ?? "active";
        if (archive !== "active" && archive !== "archived") {
          return json({ error: "SLK_WEBBI_ARCHIVE_FILTER_INVALID" }, 400);
        }
        return json({
          schema_version: "slk.webbi.runs/v1",
          bi_version: BI_VERSION,
          runs: await dependencies.store.listRuns(archive === "archived")
        });
      }
      const runMatch = url.pathname.match(/^\/api\/v1\/runs\/([^/]+)\/([^/]+)$/);
      if (runMatch && request.method === "GET") {
        const record = await dependencies.store.getRun(
          decodeURIComponent(runMatch[1]),
          decodeURIComponent(runMatch[2])
        );
        return record ? json({ schema_version: "slk.webbi.run/v1", bi_version: BI_VERSION, record }) : json({ error: "SLK_WEBBI_RUN_NOT_FOUND" }, 404);
      }
      if (url.pathname === "/api/v1/notification-settings") {
        if (request.method === "GET") {
          return json(toPublicNotificationSettings(await dependencies.store.getSettings()));
        }
        if (request.method === "PUT") {
          const input = await requestJson(request);
          const current = await dependencies.store.getSettings();
          const requestedMode = input && typeof input === "object" && !Array.isArray(input) ? input.auth_mode : void 0;
          const parsed = parseNotificationSettingsInput(input, dependencies.catalog, {
            allow_secret_reuse: requestedMode === current.auth_mode && Boolean(current.encrypted_secret && current.secret_iv)
          });
          if (parsed.auth_mode !== "none" && !parsed.secret && !canReuseNotificationSecret(current, parsed)) {
            throw new Error("SLK_WEBBI_NOTIFICATION_SECRET_REQUIRED");
          }
          return json(toPublicNotificationSettings(await dependencies.store.saveSettings(parsed)));
        }
      }
      if (url.pathname === "/api/v1/notification-settings/test" && request.method === "POST") {
        const target = await dependencies.store.notificationTarget();
        if (!target) return json({ error: "SLK_WEBBI_NOTIFICATION_NOT_CONFIGURED" }, 409);
        await dependencies.notifier.test(target);
        return json({ status: "sent" });
      }
      return json({ error: "SLK_WEBBI_ROUTE_NOT_FOUND" }, 404);
    } catch (error) {
      const code = error instanceof Error ? error.message : "SLK_WEBBI_REQUEST_FAILED";
      return json({ error: code }, code.includes("TOO_LARGE") ? 413 : 400);
    }
  };
}
__name(createWebBiHandler, "createWebBiHandler");

// ../apps/slk-bi/src/webbi/d1Store.ts
function bytesToBase64(bytes) {
  let value = "";
  for (const byte of bytes) value += String.fromCharCode(byte);
  return btoa(value);
}
__name(bytesToBase64, "bytesToBase64");
function base64ToBytes(value) {
  try {
    const decoded = atob(value);
    return Uint8Array.from(decoded, (character) => character.charCodeAt(0));
  } catch {
    throw new Error("SLK_WEBBI_ENCRYPTION_KEY_INVALID");
  }
}
__name(base64ToBytes, "base64ToBytes");
async function encryptionKey(encoded) {
  const raw = base64ToBytes(encoded);
  if (raw.byteLength !== 32) throw new Error("SLK_WEBBI_ENCRYPTION_KEY_INVALID");
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
__name(encryptionKey, "encryptionKey");
async function encryptSecret(secret, encodedKey) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    await encryptionKey(encodedKey),
    new TextEncoder().encode(secret)
  );
  return {
    encrypted_secret: bytesToBase64(new Uint8Array(ciphertext)),
    secret_iv: bytesToBase64(iv)
  };
}
__name(encryptSecret, "encryptSecret");
async function decryptSecret(ciphertext, iv, encodedKey) {
  try {
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: base64ToBytes(iv) },
      await encryptionKey(encodedKey),
      base64ToBytes(ciphertext)
    );
    return new TextDecoder().decode(plaintext);
  } catch {
    throw new Error("SLK_WEBBI_NOTIFICATION_SECRET_UNAVAILABLE");
  }
}
__name(decryptSecret, "decryptSecret");
function settingsFrom(row) {
  if (!row) {
    return {
      enabled: false,
      server_url: "https://ntfy.sh",
      topic: "slk",
      auth_mode: "none",
      username: null,
      encrypted_secret: null,
      secret_iv: null,
      selection_mode: "selected",
      selected_message_types: [],
      config_version: 0
    };
  }
  const selected = JSON.parse(row.selected_message_types_json);
  if (!Array.isArray(selected) || selected.some((item) => typeof item !== "string")) {
    throw new Error("SLK_WEBBI_NOTIFICATION_SETTINGS_CORRUPT");
  }
  return {
    enabled: row.enabled === 1,
    server_url: row.server_url,
    topic: row.topic,
    auth_mode: row.auth_mode,
    username: row.username,
    encrypted_secret: row.encrypted_secret,
    secret_iv: row.secret_iv,
    selection_mode: row.selection_mode,
    selected_message_types: selected,
    config_version: row.config_version
  };
}
__name(settingsFrom, "settingsFrom");
var D1WebBiStore = class {
  constructor(database, settingsEncryptionKey) {
    this.database = database;
    this.settingsEncryptionKey = settingsEncryptionKey;
  }
  database;
  settingsEncryptionKey;
  static {
    __name(this, "D1WebBiStore");
  }
  async ingest(envelope) {
    const device = await this.database.prepare("SELECT device_id FROM devices WHERE device_id=?1").bind(envelope.device.device_id).first();
    const bootstrap = device === null;
    await this.database.prepare(
      `INSERT INTO devices(device_id,device_name,registered_at,last_seen_at)
       VALUES(?1,?2,?3,?3)
       ON CONFLICT(device_id) DO UPDATE SET device_name=excluded.device_name,last_seen_at=excluded.last_seen_at
       WHERE excluded.last_seen_at > devices.last_seen_at`
    ).bind(
      envelope.device.device_id,
      envelope.device.device_name,
      envelope.generated_at
    ).run();
    const inserted_messages = [];
    for (const item of envelope.runs) {
      await this.database.prepare(
        `INSERT INTO runs(device_id,run_id,archived,payload_json,updated_at)
         VALUES(?1,?2,?3,?4,?5)
         ON CONFLICT(device_id,run_id) DO UPDATE SET
           archived=excluded.archived,payload_json=excluded.payload_json,updated_at=excluded.updated_at
         WHERE excluded.updated_at > runs.updated_at
           AND (runs.archived=0 OR excluded.archived=1)`
      ).bind(
        envelope.device.device_id,
        item.run.run_id,
        isArchivedRun(item.run) ? 1 : 0,
        JSON.stringify(item.run),
        envelope.generated_at
      ).run();
      for (const message of item.messages) {
        const result = await this.database.prepare(
          `INSERT OR IGNORE INTO messages
           (device_id,message_id,run_id,source_kind,message_type,payload_json,occurred_at,ingested_at)
           VALUES(?1,?2,?3,?4,?5,?6,?7,?8)`
        ).bind(
          envelope.device.device_id,
          message.message_id,
          message.run_id,
          message.source_kind,
          message.message_type,
          JSON.stringify(message),
          message.occurred_at,
          envelope.generated_at
        ).run();
        if ((result.meta?.changes ?? 0) > 0) {
          inserted_messages.push({ device: envelope.device, run: item.run, message });
        }
      }
    }
    return { bootstrap, inserted_messages };
  }
  async messages(deviceId, runId) {
    const rows = await this.database.prepare(
      `SELECT payload_json FROM messages WHERE device_id=?1 AND run_id=?2
       ORDER BY occurred_at,message_id`
    ).bind(deviceId, runId).all();
    return rows.results.map(({ payload_json }) => JSON.parse(payload_json));
  }
  async record(row) {
    return {
      device: { device_id: row.device_id, device_name: row.device_name },
      run: JSON.parse(row.payload_json),
      messages: await this.messages(row.device_id, row.run_id),
      updated_at: row.updated_at
    };
  }
  async listRuns(archived) {
    const rows = await this.database.prepare(
      `SELECT r.device_id,d.device_name,r.run_id,r.payload_json,r.updated_at
       FROM runs r JOIN devices d ON d.device_id=r.device_id
       WHERE r.archived=?1 ORDER BY r.updated_at DESC,r.device_id,r.run_id`
    ).bind(archived ? 1 : 0).all();
    return Promise.all(rows.results.map((row) => this.record(row)));
  }
  async getRun(deviceId, runId) {
    const row = await this.database.prepare(
      `SELECT r.device_id,d.device_name,r.run_id,r.payload_json,r.updated_at
       FROM runs r JOIN devices d ON d.device_id=r.device_id
       WHERE r.device_id=?1 AND r.run_id=?2`
    ).bind(deviceId, runId).first();
    return row ? this.record(row) : null;
  }
  async getSettings() {
    return settingsFrom(await this.database.prepare(
      `SELECT enabled,server_url,topic,auth_mode,username,encrypted_secret,secret_iv,
              selection_mode,selected_message_types_json,config_version
       FROM notification_settings WHERE singleton=1`
    ).first());
  }
  async saveSettings(input) {
    const current = await this.getSettings();
    let encrypted_secret = null;
    let secret_iv = null;
    if (input.auth_mode !== "none") {
      if (input.secret) {
        ({ encrypted_secret, secret_iv } = await encryptSecret(
          input.secret,
          this.settingsEncryptionKey
        ));
      } else if (canReuseNotificationSecret(current, input)) {
        encrypted_secret = current.encrypted_secret;
        secret_iv = current.secret_iv;
      } else {
        throw new Error("SLK_WEBBI_NOTIFICATION_SECRET_REQUIRED");
      }
    }
    const version = current.config_version + 1;
    await this.database.prepare(
      `INSERT INTO notification_settings
       (singleton,enabled,server_url,topic,auth_mode,username,encrypted_secret,secret_iv,
        selection_mode,selected_message_types_json,config_version,updated_at)
       VALUES(1,?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11)
       ON CONFLICT(singleton) DO UPDATE SET
        enabled=excluded.enabled,server_url=excluded.server_url,topic=excluded.topic,
        auth_mode=excluded.auth_mode,username=excluded.username,
        encrypted_secret=excluded.encrypted_secret,secret_iv=excluded.secret_iv,
        selection_mode=excluded.selection_mode,
        selected_message_types_json=excluded.selected_message_types_json,
        config_version=excluded.config_version,updated_at=excluded.updated_at`
    ).bind(
      input.enabled ? 1 : 0,
      input.server_url,
      input.topic,
      input.auth_mode,
      input.username ?? null,
      encrypted_secret,
      secret_iv,
      input.selection_mode,
      JSON.stringify(input.selected_message_types),
      version,
      (/* @__PURE__ */ new Date()).toISOString()
    ).run();
    return this.getSettings();
  }
  async notificationTarget() {
    const settings = await this.getSettings();
    if (!settings.enabled) return null;
    const secret = settings.encrypted_secret && settings.secret_iv ? await decryptSecret(
      settings.encrypted_secret,
      settings.secret_iv,
      this.settingsEncryptionKey
    ) : null;
    return { settings, secret };
  }
  async hasDelivery(key) {
    const row = await this.database.prepare(
      "SELECT status FROM notification_deliveries WHERE delivery_key=?1"
    ).bind(key).first();
    return row?.status === "sent";
  }
  async recordDelivery(key, status, error) {
    await this.database.prepare(
      `INSERT INTO notification_deliveries(delivery_key,status,error,attempted_at)
       VALUES(?1,?2,?3,?4)
       ON CONFLICT(delivery_key) DO UPDATE SET
         status=excluded.status,error=excluded.error,attempted_at=excluded.attempted_at`
    ).bind(key, status, error ?? null, (/* @__PURE__ */ new Date()).toISOString()).run();
  }
};

// ../apps/slk-bi/src/webbi/ntfy.ts
function endpoint(target) {
  return `${target.settings.server_url.replace(/\/$/, "")}/${encodeURIComponent(target.settings.topic)}`;
}
__name(endpoint, "endpoint");
function authorization(target) {
  if (target.settings.auth_mode === "token" && target.secret) {
    return `Bearer ${target.secret}`;
  }
  if (target.settings.auth_mode === "password" && target.settings.username && target.secret) {
    return `Basic ${btoa(`${target.settings.username}:${target.secret}`)}`;
  }
  return void 0;
}
__name(authorization, "authorization");
async function publish(target, body, title) {
  const headers = new Headers({
    "content-type": "text/plain; charset=utf-8",
    title,
    tags: "information_source"
  });
  const auth = authorization(target);
  if (auth) headers.set("authorization", auth);
  const response = await fetch(endpoint(target), { method: "POST", headers, body });
  if (!response.ok) throw new Error(`SLK_WEBBI_NTFY_REJECTED:${response.status}`);
}
__name(publish, "publish");
var NtfyNotifier = class {
  static {
    __name(this, "NtfyNotifier");
  }
  async send(target, record) {
    const scope = [record.message.go_id, record.message.cell_id].filter(Boolean).join(" \xB7 ");
    await publish(
      target,
      [
        `${record.run.summary.run_name} \xB7 ${record.message.label_zh}`,
        `${record.message.author_role}${scope ? ` \xB7 ${scope}` : ""}`,
        `\u8BBE\u5907\uFF1A${record.device.device_name} (${record.device.device_id})`
      ].join("\n"),
      `SLK \xB7 ${record.run.summary.run_name}`
    );
  }
  async test(target) {
    await publish(target, `WebBI ${BI_VERSION} \u7684 ntfy \u914D\u7F6E\u6D4B\u8BD5\u6210\u529F\u3002`, "SLK WebBI \u6D4B\u8BD5");
  }
};

// ../apps/slk-bi/src/webbi/cloudflare.ts
var cloudflare_default = {
  async fetch(request, environment) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return environment.ASSETS.fetch(request);
    const handler = createWebBiHandler({
      store: new D1WebBiStore(environment.DB, environment.WEBBI_SETTINGS_ENCRYPTION_KEY),
      notifier: new NtfyNotifier(),
      catalog: MESSAGE_CATALOG,
      ingest_token: environment.WEBBI_INGEST_TOKEN
    });
    return handler(request);
  }
};
export {
  cloudflare_default as default
};
//# sourceMappingURL=cloudflare.js.map
