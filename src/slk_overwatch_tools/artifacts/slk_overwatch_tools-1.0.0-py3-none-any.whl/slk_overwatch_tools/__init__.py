"""Deterministic, read-only Overwatcher helpers with no transport/state authority."""
from .cadence import OverwatcherContinuityError, inspect_cadence
from .native_records import (
    OverwatcherSubagentError, native_object, read_codex_subagent_snapshot,
)

__version__ = "1.0.0"
__all__ = ["OverwatcherContinuityError", "OverwatcherSubagentError", "inspect_cadence",
           "native_object", "read_codex_subagent_snapshot"]
