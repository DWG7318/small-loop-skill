// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 alibaba/open-code-review Contributors

package scan

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	allowedext "github.com/alibaba/open-code-review/internal/config/allowlist"
	"github.com/alibaba/open-code-review/internal/config/rules"
	"github.com/alibaba/open-code-review/internal/config/template"
	"github.com/alibaba/open-code-review/internal/gitcmd"
	"github.com/alibaba/open-code-review/internal/llm"
	"github.com/alibaba/open-code-review/internal/llmloop"
	"github.com/alibaba/open-code-review/internal/model"
	"github.com/alibaba/open-code-review/internal/session"
	"github.com/alibaba/open-code-review/internal/stdout"
	"github.com/alibaba/open-code-review/internal/telemetry"
	"github.com/alibaba/open-code-review/internal/tool"
)

// changeFilesScanLiteral substitutes for the {{change_files}} placeholder.
// Full-scan has no "other changed files" concept; using a fixed sentinel is
// less misleading than leaving the placeholder empty.
const changeFilesScanLiteral = "(not applicable in full-scan mode)"

// Args bundles all dependencies needed for one scan session.
//
// Note: Template is the scan-specific template.ScanTemplate (loaded from
// scan_template.json), not the diff-review template.Template. The two are
// intentionally separate so review/scan prompts evolve independently.
//
// MaxFileSizeBytes overrides the default 2 MiB per-file size cap; it is
// usually populated from ScanTemplate.MaxFileSizeBytes via scan_cmd.
type Args struct {
	RepoDir               string
	Paths                 []string // empty = whole repo
	Template              template.ScanTemplate
	SystemRule            rules.Resolver
	FileFilter            *rules.FileFilter
	LLMClient             llm.LLMClient
	Tools                 *tool.Registry
	MainToolDefs          []llm.ToolDef
	CommentCollector      *tool.CommentCollector
	CommentWorkerPool     *llmloop.CommentWorkerPool
	MaxConcurrency        int
	ConcurrentTaskTimeout int
	Model                 string
	EndpointSource        string
	Background            string
	GitRunner             *gitcmd.Runner
	Session               *session.SessionHistory
	// Resume is an optional read-only checkpoint index from a previous scan
	// session.
	Resume *session.ResumeState

	MaxFileSizeBytes int64
	// SkipPlan disables the PLAN_TASK pre-pass even when the template
	// defines one. Set via the --no-plan CLI flag.
	SkipPlan bool
	// SkipDedup disables the per-batch DEDUP_TASK even when the template
	// defines one. Set via the --no-dedup CLI flag.
	SkipDedup bool
	// SkipSummary disables the post-run PROJECT_SUMMARY_TASK even when the
	// template defines one. Set via the --no-summary CLI flag.
	SkipSummary bool
	// MaxTokensBudget, when > 0, caps total token usage (input+output, as
	// reported by the API). Once the running total exceeds it, no further
	// batches are dispatched. 0 = unlimited. Set via --max-tokens-budget
	// or ScanTemplate.MaxTokensBudget.
	MaxTokensBudget int64
}

// planEnabled / dedupEnabled / summaryEnabled report whether each optional
// phase will actually run: template must define it AND the corresponding
// --no-* flag must not be set. Used by both cost estimation and dispatch.
func (a *Agent) planEnabled() bool {
	return !a.args.SkipPlan && a.args.Template.PlanTask != nil && len(a.args.Template.PlanTask.Messages) > 0
}

func (a *Agent) dedupEnabled() bool {
	return !a.args.SkipDedup && a.args.Template.DedupTask != nil && len(a.args.Template.DedupTask.Messages) > 0
}

func (a *Agent) summaryEnabled() bool {
	return !a.args.SkipSummary && a.args.Template.ProjectSummaryTask != nil && len(a.args.Template.ProjectSummaryTask.Messages) > 0
}

// Agent orchestrates full-file code review. It delegates the per-file LLM
// tool-use loop to llmloop.Runner and owns only scan-specific concerns
// (file enumeration, FULL_SCAN_TASK rendering, per-file filtering).
type Agent struct {
	args             Args
	items            []model.ScanItem
	currentDate      string
	session          *session.SessionHistory
	subtaskFailed    int64 // atomic
	runner           *llmloop.Runner
	resumeInfo       *session.ResumeInfo
	scanFingerprints map[string]string
	projectSummary   string // populated post-run by maybeRunProjectSummary
	budgetExceeded   bool   // set when the token budget gate stopped dispatch; written only by dispatchBatch's loop
}

// ProjectSummary returns the markdown project-level summary produced after
// all batches finish. Empty when SkipSummary is set, PROJECT_SUMMARY_TASK
// is absent, no comments were collected, or the summary LLM call failed.
func (a *Agent) ProjectSummary() string { return a.projectSummary }

// NewAgent creates a scan Agent from the given args. The Session is
// auto-created (review_mode = full_scan) when not supplied.
func NewAgent(args Args) *Agent {
	if args.Tools == nil {
		args.Tools = tool.NewRegistry()
	}
	if args.CommentCollector == nil {
		args.CommentCollector = tool.NewCommentCollector()
	}
	if args.Session == nil {
		args.Session = session.New(args.RepoDir, "", args.Model, session.SessionOptions{
			ReviewMode:  session.ReviewModeFullScan,
			ScanPaths:   args.Paths,
			ResumedFrom: resumedFromSession(args.Resume),
			LLMSource:   args.EndpointSource,
		})
	}
	a := &Agent{
		args:    args,
		session: args.Session,
	}
	a.runner = llmloop.NewRunner(llmloop.Deps{
		LLMClient:         args.LLMClient,
		Model:             args.Model,
		Template:          toLoopTemplate(args.Template),
		Tools:             args.Tools,
		MainToolDefs:      args.MainToolDefs,
		CommentCollector:  args.CommentCollector,
		CommentWorkerPool: args.CommentWorkerPool,
		Session:           args.Session,
		// DiffLookup returns a synthetic Diff so the code_comment tool's
		// line-number resolver (resolveFromFileContent) can match against
		// the full file content of the scanned file.
		DiffLookup:      a.lookupDiff,
		MaxTokensBudget: args.MaxTokensBudget,
		// NewRequestMeta is deliberately left nil. The retry report describes
		// ocr review; scan shares this Runner, and a nil factory is what keeps
		// scan's requests out of the report. See llmloop.Deps.NewRequestMeta.
	})
	return a
}

// toLoopTemplate maps the scan-specific ScanTemplate onto the subset of
// fields llmloop.Runner reads from template.Template. llmloop only needs
// MaxTokens / MaxToolRequestTimes / MemoryCompressionTask / ReLocationTask,
// so we leave the diff-only fields (MainTask / PlanTask / ReviewFilterTask)
// at their zero values.
func toLoopTemplate(s template.ScanTemplate) template.Template {
	return template.Template{
		MemoryCompressionTask: s.MemoryCompressionTask,
		MaxTokens:             s.MaxTokens,
		MaxCompletionTokens:   s.CompletionTokenLimit(),
		MaxToolRequestTimes:   s.MaxToolRequestTimes,
		ReLocationTask:        s.ReLocationTask,
	}
}

// Session returns the session history associated with this Agent.
func (a *Agent) Session() *session.SessionHistory { return a.session }

// SessionID returns the current scan's persisted session ID. It returns an empty
// string when no session file exists.
func (a *Agent) SessionID() string {
	if a == nil || a.session == nil || !a.session.HasPersistence() {
		return ""
	}
	return a.session.SessionID
}

// RunManifest returns nil because scan is intentionally outside the v1 run
// manifest scope. It exists so review and scan can share the output pipeline
// without synthesizing a manifest for scan.
func (a *Agent) RunManifest() *session.RunManifest { return nil }

// ResumeInfo returns resume metadata for output. Nil means this was not a resume run.
func (a *Agent) ResumeInfo() *session.ResumeInfo {
	if a.resumeInfo == nil {
		return nil
	}
	info := *a.resumeInfo
	return &info
}

// FilesReviewed returns the number of items included in this scan.
func (a *Agent) FilesReviewed() int64 { return int64(len(a.items)) }

// Diffs returns the scanned items adapted to model.Diff form so callers
// (e.g. cmd/opencodereview's outputJSON / ResolveLineNumbers) can treat
// both review and scan results uniformly.
func (a *Agent) Diffs() []model.Diff {
	out := make([]model.Diff, len(a.items))
	for i := range a.items {
		out[i] = *a.items[i].AsDiff()
	}
	return out
}

// TotalTokensUsed / TotalInputTokens / ... delegate to the underlying runner.
func (a *Agent) TotalTokensUsed() int64      { return a.runner.TotalTokensUsed() }
func (a *Agent) TotalInputTokens() int64     { return a.runner.TotalInputTokens() }
func (a *Agent) TotalOutputTokens() int64    { return a.runner.TotalOutputTokens() }
func (a *Agent) TotalCacheReadTokens() int64 { return a.runner.TotalCacheReadTokens() }
func (a *Agent) TotalCacheWriteTokens() int64 {
	return a.runner.TotalCacheWriteTokens()
}

// Warnings returns the warnings recorded by the LLM runner.
func (a *Agent) Warnings() []llmloop.AgentWarning { return a.runner.Warnings() }

// ToolCalls returns per-tool call counts accumulated during scan.
func (a *Agent) ToolCalls() map[string]int64 { return a.runner.ToolCalls() }

// ToolFailures returns failed registered-tool calls accumulated during scan.
func (a *Agent) ToolFailures() []llmloop.ToolFailureDetail { return a.runner.ToolFailures() }

// BudgetExceeded reports whether the aggregate token budget gate stopped
// dispatch before every file was reviewed. Diagnostic only: scan still returns
// its partial comments and a nil error, and the value reaches output solely as
// summary.budget_exceeded. Per-file MaxToolRequestTimes exhaustion does NOT set
// it — that is an item-level outcome, not a run-level budget stop.
func (a *Agent) BudgetExceeded() bool { return a.budgetExceeded }

func (a *Agent) recordWarning(warningType, file, message string) {
	a.runner.RecordWarning(warningType, file, message)
}

func (a *Agent) initScanFingerprints(items []model.ScanItem) {
	if len(items) == 0 {
		return
	}
	a.scanFingerprints = make(map[string]string, len(items))
	for _, it := range items {
		a.scanFingerprints[it.Path] = scanItemFingerprint(it)
	}
}

func (a *Agent) scanItemFingerprint(it model.ScanItem) string {
	if a != nil && a.scanFingerprints != nil {
		if fingerprint := a.scanFingerprints[it.Path]; fingerprint != "" {
			return fingerprint
		}
	}
	return scanItemFingerprint(it)
}

func (a *Agent) initResumeInfo(items []model.ScanItem) {
	resume := a.args.Resume
	if resume == nil {
		return
	}
	var reused int64
	var rerun int64
	for _, it := range items {
		if _, ok := resume.Item(a.scanItemFingerprint(it)); ok {
			reused++
		} else {
			rerun++
		}
	}
	a.resumeInfo = &session.ResumeInfo{
		ResumedFrom:   resume.SessionID,
		ReusedFiles:   reused,
		RerunFiles:    rerun,
		PreviousModel: resume.Model,
		CurrentModel:  a.args.Model,
	}
	fmt.Fprintf(stdout.Writer(), "[ocr] Resume %s: reusing %d file(s), reviewing %d file(s)\n", resume.SessionID, reused, rerun)
}

func (a *Agent) resumeItem(fingerprint string) (session.ResumeItem, bool) {
	if a.args.Resume == nil {
		return session.ResumeItem{}, false
	}
	return a.args.Resume.Item(fingerprint)
}

func scanItemFingerprint(it model.ScanItem) string {
	sum := sha256.Sum256([]byte(session.ReviewModeFullScan + "\x00" + it.Path + "\x00" + it.Content))
	return fmt.Sprintf("%x", sum)
}

func resumedFromSession(resume *session.ResumeState) string {
	if resume == nil {
		return ""
	}
	return resume.SessionID
}

// Run executes the full-scan pipeline: enumerate → filter → token-filter →
// dispatch one subtask per file → collect comments.
func (a *Agent) Run(ctx context.Context) ([]model.LlmComment, error) {
	if len(a.args.Template.MainTask.Messages) == 0 {
		return nil, fmt.Errorf("scan template MAIN_TASK is missing or empty")
	}

	// Base prompt-cache affinity key for any LLM request in this run that a
	// task doesn't re-scope. Each task conversation (plan, per-file main
	// loop, dedup, summary) refines it with llm.SessionTaskKey where it
	// starts, so affinity keys stay per-conversation — the granularity
	// provider prompt caches actually reuse prefixes at.
	ctx = llm.ContextWithSessionKey(ctx, a.SessionID())

	ctx, scanSpan := telemetry.StartSpan(ctx, "scan.enumerate")
	provider := NewProvider(a.args.RepoDir, a.args.Paths, a.args.GitRunner, a.args.MaxFileSizeBytes)
	items, err := provider.Enumerate(ctx)
	if err != nil {
		scanSpan.End()
		return nil, fmt.Errorf("enumerate files: %w", err)
	}
	telemetry.SetAttr(scanSpan, "files.enumerated", len(items))
	scanSpan.End()

	a.items = items
	a.injectScanContentMap()
	a.args.Tools.Freeze()

	totalDiscovered := len(a.items)
	decisions := a.selectScanItems(a.items)
	a.logSelection(decisions)
	a.items = selectedScanItems(decisions)

	reviewable := len(a.items)
	fmt.Fprintf(stdout.Writer(), "[ocr] full-scan: %d file(s) discovered, reviewing %d in %s\n",
		totalDiscovered, reviewable, a.args.RepoDir)

	if reviewable == 0 {
		fmt.Fprintln(stdout.Writer(), "[ocr] No reviewable files. Skipping scan.")
		telemetry.Event(ctx, "scan.no.files")
		// A clean skip still has to reach disk: if session_end never persisted,
		// the skip cannot be claimed. Scan has no manifest builder, but the
		// session_end delivery contract still applies.
		if ferr := a.session.Finalize(); ferr != nil {
			return []model.LlmComment{}, fmt.Errorf("finalize session: %w", ferr)
		}
		return []model.LlmComment{}, nil
	}

	// Pre-run cost projection so users aren't surprised by a large scan.
	est := estimateCost(a.items, a.planEnabled(), a.dedupEnabled(), a.summaryEnabled())
	fmt.Fprintf(stdout.Writer(), "[ocr] estimated cost: %s\n", est)
	if a.args.MaxTokensBudget > 0 {
		fmt.Fprintf(stdout.Writer(), "[ocr] token budget: %s (dispatch stops once exceeded)\n", humanTokens(a.args.MaxTokensBudget))
		if est.TotalTokens > a.args.MaxTokensBudget {
			fmt.Fprintf(stdout.Writer(), "[ocr] WARNING: estimate (%s) exceeds budget (%s); scan will stop partway\n",
				humanTokens(est.TotalTokens), humanTokens(a.args.MaxTokensBudget))
		}
	}

	a.currentDate = time.Now().Format("2006-01-02 15:04")
	telemetry.Event(ctx, "scan.started",
		telemetry.AnyToAttr("file.count", totalDiscovered),
		telemetry.AnyToAttr("review.count", reviewable),
		telemetry.AnyToAttr("est.total.tokens", est.TotalTokens),
		telemetry.AnyToAttr("repo.dir", a.args.RepoDir))
	telemetry.RecordFilesReviewed(ctx, int64(reviewable))

	comments, err := a.dispatchSubtasks(ctx)
	if len(comments) > 0 {
		telemetry.RecordCommentsGenerated(ctx, int64(len(comments)))
	}

	// Project-level summary runs after all batches; never blocks return.
	a.maybeRunProjectSummary(ctx, comments)

	// Join background memory compression before anything finalizes the session.
	// Those jobs are cancelled rather than awaited when a conversation ends, so
	// their LLM request can still be in flight here; joining them ensures no
	// background goroutine is left leaking or writing to a finalized session.
	a.runner.WaitBackground()

	// A persistence failure is a delivery error in its own right: when the scan
	// also failed, both facts are reported (errors.Join) rather than letting the
	// dispatch error hide the fact that session_end never reached disk.
	if ferr := a.session.Finalize(); ferr != nil {
		finalizeErr := fmt.Errorf("finalize session: %w", ferr)
		if err != nil {
			err = errors.Join(err, finalizeErr)
		} else {
			err = finalizeErr
		}
	}
	return comments, err
}

// lookupDiff returns the synthetic Diff for a path, used by llmloop.Runner
// to resolve code_comment line numbers against the scanned file content.
func (a *Agent) lookupDiff(path string) *model.Diff {
	for i := range a.items {
		if a.items[i].Path == path {
			return a.items[i].AsDiff()
		}
	}
	return nil
}

// injectScanContentMap fills the file_read_diff tool's DiffMap with full
// file content keyed by path, so if the model calls it the tool returns
// the whole file rather than failing.
func (a *Agent) injectScanContentMap() {
	m := make(map[string]string, len(a.items))
	for i := range a.items {
		it := &a.items[i]
		if it.Path != "" {
			m[it.Path] = it.Content
		}
	}
	dm := tool.NewDiffMap(m)
	if p, ok := a.args.Tools.Get(tool.FileReadDiff.Name()); ok {
		if frd, ok := p.(*tool.FileReadDiffProvider); ok {
			frd.SetDiffMap(dm)
		}
	}
}

type scanSelection struct {
	item   model.ScanItem
	reason model.ExcludeReason
	tokens int
}

// selectScanItems is the single pre-dispatch selection pass shared by Run and
// Preview. Keep the size check after the normal reviewability rules so an item
// has one stable exclusion reason and the two paths cannot drift.
func (a *Agent) selectScanItems(items []model.ScanItem) []scanSelection {
	limit := llmloop.PromptTokenLimit(a.args.Template.MaxTokens)
	decisions := make([]scanSelection, 0, len(items))
	for _, it := range items {
		decision := scanSelection{
			item:   it,
			reason: a.whyExcluded(it),
		}
		if decision.reason == model.ExcludeNone && limit > 0 {
			decision.tokens = llm.CountTokens(it.Content)
			if decision.tokens > limit {
				decision.reason = model.ExcludeTooLarge
			}
		}
		decisions = append(decisions, decision)
	}
	return decisions
}

func selectedScanItems(decisions []scanSelection) []model.ScanItem {
	kept := make([]model.ScanItem, 0, len(decisions))
	for _, decision := range decisions {
		if decision.reason == model.ExcludeNone {
			kept = append(kept, decision.item)
		}
	}
	return kept
}

func (a *Agent) logSelection(decisions []scanSelection) {
	staticSkipped := 0
	for _, decision := range decisions {
		if decision.reason == model.ExcludeNone || decision.reason == model.ExcludeTooLarge {
			continue
		}
		if decision.item.IsBinary {
			fmt.Fprintf(stdout.Writer(), "[ocr] Skipping %s — binary file\n", decision.item.Path)
		} else if decision.reason == model.ExcludeSecret {
			fmt.Fprintf(stdout.Writer(), "[ocr] Skipping %s — matches a built-in secret path\n", decision.item.Path)
		} else {
			fmt.Fprintf(stdout.Writer(), "[ocr] Skipping %s — filtered by path/extension rules\n", decision.item.Path)
		}
		staticSkipped++
	}
	if staticSkipped > 0 {
		fmt.Fprintf(stdout.Writer(), "[ocr] Filtered %d file(s) by include/exclude rules\n", staticSkipped)
	}

	largeSkipped := 0
	for _, decision := range decisions {
		if decision.reason != model.ExcludeTooLarge {
			continue
		}
		fmt.Fprintf(stdout.Writer(), "[ocr] Skipping %s (~%d tokens exceeds 80%% of max_tokens(%d))\n",
			decision.item.Path, decision.tokens, a.args.Template.MaxTokens)
		largeSkipped++
	}
	if largeSkipped > 0 {
		fmt.Fprintf(stdout.Writer(), "[ocr] Pre-filtered %d file(s) exceeding 80%% of max_tokens\n", largeSkipped)
	}
}

// whyExcluded mirrors agent.whyExcluded but for ScanItem inputs.
func (a *Agent) whyExcluded(it model.ScanItem) model.ExcludeReason {
	if it.IsBinary {
		return model.ExcludeBinary
	}
	path := it.Path
	// Ahead of both user rules, matching internal/agent: no include glob can
	// admit a credential path, and no user exclude can reclassify it. See #1240.
	if allowedext.IsSecretPath(path) {
		return model.ExcludeSecret
	}
	if a.args.FileFilter != nil && a.args.FileFilter.IsUserExcluded(path) {
		return model.ExcludeUserRule
	}
	// User-include is checked before the extension allowlist (matching the
	// preview/diff path in internal/agent) so an explicit include glob can
	// admit otherwise-unsupported extensions (e.g. .ftl). See #371.
	if a.args.FileFilter != nil && a.args.FileFilter.HasInclude() && a.args.FileFilter.IsUserIncluded(path) {
		return model.ExcludeNone
	}
	ext := extFromPath(path)
	if ext != "" && !allowedext.IsAllowedExt(ext) {
		return model.ExcludeExtension
	}
	if allowedext.IsExcludedPath(path) {
		return model.ExcludeDefaultPath
	}
	return model.ExcludeNone
}

func extFromPath(path string) string {
	basename := path
	if idx := strings.LastIndex(path, "/"); idx >= 0 {
		basename = path[idx+1:]
	}
	dot := strings.LastIndex(basename, ".")
	if dot <= 0 {
		return ""
	}
	return strings.ToLower(basename[dot:])
}

// dispatchSubtasks groups items into batches per the configured strategy,
// then processes batches sequentially while running files within each
// batch concurrently up to MaxConcurrency. Sequential batches enable
// future per-batch hooks (e.g. Phase 6 dedup) and improve LLM prompt-cache
// hit rate by keeping same-language files adjacent in time.
func (a *Agent) dispatchSubtasks(ctx context.Context) ([]model.LlmComment, error) {
	startTime := time.Now()
	defer func() {
		telemetry.RecordReviewDuration(ctx, time.Since(startTime))
	}()

	if len(a.items) == 0 {
		return []model.LlmComment{}, nil
	}

	atomic.StoreInt64(&a.subtaskFailed, 0)
	a.initScanFingerprints(a.items)
	a.initResumeInfo(a.items)

	strategy := a.resolveBatchStrategy()
	batches := groupBatches(a.items, strategy, a.args.Template.BatchSize)
	fmt.Fprintf(stdout.Writer(), "[ocr] scan dispatch: %d batch(es) by %s strategy\n", len(batches), strategy)

	var dispatched int64
	for bi, batch := range batches {
		if err := ctx.Err(); err != nil {
			return a.args.CommentCollector.Comments(), err
		}
		// Snapshot the collector so we can isolate comments added by *this*
		// batch and feed them into the per-batch dedup hook.
		batchStart := a.args.CommentCollector.Snapshot()

		n, budgetHit, checkpoints, err := a.dispatchBatch(ctx, bi, batch)
		dispatched += n
		if err != nil {
			// ctx cancelled mid-batch: stop scheduling further batches but
			// still return whatever we've collected so far.
			// Persist completed items so the next resume does not scan them again.
			a.recordBatchCheckpoints(checkpoints, batchStart, nil)
			return a.args.CommentCollector.Comments(), err
		}

		// Drain async comment workers BEFORE dedup so all of this batch's
		// comments are visible. recordBatchCheckpoints has its own Await for
		// checkpoint correctness; this one keeps the dedup input complete.
		// CommentWorkerPool.Await is cumulative across batches - that is fine
		// since batches are sequential here.
		if a.args.CommentWorkerPool != nil {
			a.args.CommentWorkerPool.Await()
		}

		dedupCheckpoints := a.maybeRunDedup(ctx, bi, batchStart)
		a.recordBatchCheckpoints(checkpoints, batchStart, dedupCheckpoints)

		// The per-file budget gate inside dispatchBatch tripped — stop
		// scheduling any remaining batches.
		if budgetHit {
			break
		}
	}

	failed := atomic.LoadInt64(&a.subtaskFailed)
	if failed > 0 && failed == dispatched {
		return nil, fmt.Errorf("all %d file scan(s) failed — check your LLM configuration and API key", dispatched)
	}
	return a.args.CommentCollector.Comments(), nil
}

type batchCheckpoint struct {
	item             model.ScanItem
	reused           bool
	originalComments []model.LlmComment
}

// recordBatchCheckpoints persists safe per-file comments after batch dedup.
// New same-file groups use the canonical result. Reused items keep their source
// checkpoint, and cross-file groups keep raw per-file comments so invalidating
// one file cannot erase another file's finding on resume.
func (a *Agent) recordBatchCheckpoints(
	checkpoints []batchCheckpoint,
	batchStart int,
	dedupCheckpoints map[string][]model.LlmComment,
) {
	if len(checkpoints) == 0 {
		return
	}
	if a.args.CommentWorkerPool != nil {
		a.args.CommentWorkerPool.Await()
	}
	finalCommentsByPath := groupCommentsByPath(a.args.CommentCollector.Since(batchStart))
	for _, checkpoint := range checkpoints {
		fingerprint := a.scanItemFingerprint(checkpoint.item)
		comments := finalCommentsByPath[checkpoint.item.Path]
		if checkpoint.reused {
			comments = checkpoint.originalComments
			sourceSessionID := ""
			if a.args.Resume != nil {
				sourceSessionID = a.args.Resume.SessionID
			}
			a.session.RecordReviewItemReused(checkpoint.item.Path, checkpoint.item.Path, checkpoint.item.Path,
				fingerprint, sourceSessionID, comments)
			continue
		}
		if dedupCheckpoints != nil {
			comments = dedupCheckpoints[checkpoint.item.Path]
		}
		a.session.RecordReviewItemDone(checkpoint.item.Path, checkpoint.item.Path, checkpoint.item.Path, fingerprint, comments)
	}
}

func groupCommentsByPath(comments []model.LlmComment) map[string][]model.LlmComment {
	byPath := make(map[string][]model.LlmComment)
	for _, comment := range comments {
		byPath[comment.Path] = append(byPath[comment.Path], comment)
	}
	return byPath
}

// resolveBatchStrategy reads the strategy from the scan template, defaulting
// to BatchNone for unrecognized / empty values.
func (a *Agent) resolveBatchStrategy() BatchStrategy {
	return parseBatchStrategy(a.args.Template.BatchStrategy)
}

// dispatchBatch fans out the files of a single batch concurrently and
// blocks until they all finish (or ctx is cancelled). Returns the number
// of files dispatched, whether the token budget was hit mid-batch, the
// completed/reused files whose checkpoints need recording, and ctx.Err()
// if cancelled.
//
// The budget gate is checked per file, right after acquiring the
// concurrency slot and before launching the subtask: if the tokens already
// spent PLUS a look-ahead estimate of this file's cost would exceed the
// budget, the file (and all remaining files in the batch) are skipped.
// This keeps overrun bounded by roughly one in-flight file per worker,
// instead of a whole batch as the coarse batch-level gate did.
func (a *Agent) dispatchBatch(ctx context.Context, batchIdx int, batch []model.ScanItem) (int64, bool, []batchCheckpoint, error) {
	concurrency := a.args.MaxConcurrency
	if concurrency <= 0 {
		concurrency = 8
	}
	sem := make(chan struct{}, concurrency)
	timeout := time.Duration(a.args.ConcurrentTaskTimeout) * time.Minute

	var (
		wg            sync.WaitGroup
		dispatched    int64
		budgetHit     bool
		checkpointsMu sync.Mutex
		checkpoints   []batchCheckpoint
	)

	for i := range batch {
		it := batch[i]
		fingerprint := a.scanItemFingerprint(it)
		if item, ok := a.resumeItem(fingerprint); ok {
			for _, cm := range item.Comments {
				a.args.CommentCollector.Add(cm)
			}
			checkpointsMu.Lock()
			checkpoints = append(checkpoints, batchCheckpoint{
				item:             it,
				reused:           true,
				originalComments: item.Comments,
			})
			checkpointsMu.Unlock()
			continue
		}

		// Per-file budget look-ahead. Stop before acquiring a slot so we
		// don't even queue work that would blow the budget.
		if a.args.MaxTokensBudget > 0 {
			used := a.runner.TotalTokensUsed()
			projected := used + estimateFileTokens(it, a.planEnabled())
			if projected > a.args.MaxTokensBudget {
				fmt.Fprintf(stdout.Writer(), "[ocr] token budget reached (used %s + next-file est ≈ %s > budget %s) — skipping %s and remaining files\n",
					humanTokens(used), humanTokens(projected), humanTokens(a.args.MaxTokensBudget), it.Path)
				a.recordWarning("token_budget_reached", it.Path,
					fmt.Sprintf("stopped in batch #%d: used %d tokens + next-file estimate exceeds budget %d", batchIdx, used, a.args.MaxTokensBudget))
				budgetHit = true
				// budgetHit is per-batch and dies with this call; the field is
				// the run-level signal emitRunResult reads after Run returns.
				a.budgetExceeded = true
				break
			}
		}

		select {
		case sem <- struct{}{}:
		case <-ctx.Done():
			wg.Wait()
			return dispatched, budgetHit, checkpoints, ctx.Err()
		}

		dispatched++
		wg.Add(1)
		go func(it model.ScanItem, fingerprint string) {
			defer wg.Done()
			defer func() { <-sem }()

			var fileCtx context.Context
			var cancel context.CancelFunc
			if timeout > 0 {
				fileCtx, cancel = context.WithTimeout(ctx, timeout)
				defer cancel()
			} else {
				fileCtx = ctx
			}

			completedOK, skipReason, err := a.executeSubtask(fileCtx, it)
			if err != nil {
				atomic.AddInt64(&a.subtaskFailed, 1)
				a.session.RecordReviewItemFailed(it.Path, it.Path, it.Path, fingerprint, err.Error())
				fmt.Fprintf(stdout.Writer(), "[ocr] Scan subtask error for %s (batch #%d): %v\n", it.Path, batchIdx, err)
				telemetry.ErrorEvent(fileCtx, "scan.subtask.error", err,
					telemetry.AnyToAttr("file.path", it.Path),
					telemetry.AnyToAttr("batch.index", batchIdx))
				a.recordWarning("scan_subtask_error", it.Path, err.Error())
				return
			}
			if !completedOK {
				if skipReason != "" {
					atomic.AddInt64(&a.subtaskFailed, 1)
					a.session.RecordReviewItemFailed(it.Path, it.Path, it.Path, fingerprint, skipReason)
					a.recordWarning("scan_subtask_error", it.Path, skipReason)
				}
				return
			}
			checkpointsMu.Lock()
			checkpoints = append(checkpoints, batchCheckpoint{item: it})
			checkpointsMu.Unlock()
		}(it, fingerprint)
	}

	wg.Wait()
	return dispatched, budgetHit, checkpoints, nil
}

// executeSubtask runs the scan pipeline for one file:
//  1. Optional PLAN_TASK: produce a JSON checklist of focus areas.
//  2. MAIN_TASK: review the file with the plan's checkpoints embedded as
//     {{plan_guidance}}.
//
// Plan phase is skipped (and {{plan_guidance}} is filled with a "no plan"
// sentinel) when Template.PlanTask is nil, args.SkipPlan is true, the file
// is small enough that planning overhead outweighs gain, or the plan call
// itself fails. Plan failure never blocks the main review — it falls back
// to v1 (plan-less) behavior.
func (a *Agent) executeSubtask(ctx context.Context, it model.ScanItem) (bool, string, error) {
	ctx, span := telemetry.StartSpan(ctx, "scan.subtask."+it.Path)
	defer span.End()
	telemetry.SetAttr(span, "file.path", it.Path)

	if ctx.Err() != nil {
		return false, "", ctx.Err()
	}

	rule := ""
	if a.args.SystemRule != nil {
		rule = a.args.SystemRule.Resolve(it.Path)
	}

	planGuidance := a.maybeRunPlan(ctx, it, rule)

	messages := a.renderMessages(it, rule, planGuidance)

	tokenCount := llmloop.CountMessagesTokens(messages)
	maxAllowed := a.args.Template.MaxTokens
	tokenLimit := llmloop.PromptTokenLimit(maxAllowed)
	if tokenCount > tokenLimit {
		msg := fmt.Sprintf("prompt tokens (%d) exceed %d%% of max_tokens(%d)", tokenCount, 80, maxAllowed)
		fmt.Fprintf(stdout.Writer(), "[ocr] WARNING: %s for %s\n", msg, it.Path)
		a.recordWarning("token_threshold_exceeded", it.Path, msg)
		telemetry.Event(ctx, "token.threshold.exceeded",
			telemetry.AnyToAttr("file.path", it.Path),
			telemetry.AnyToAttr("tokens", tokenCount),
			telemetry.AnyToAttr("max_tokens", maxAllowed))
		return false, "", nil
	}

	completed, stop, err := a.runner.RunMainTask(ctx, messages, it.Path)
	if err != nil {
		return false, "", err
	}
	if !completed {
		// Scan sessions opt out of the run manifest, so this one string is the
		// whole diagnostic: it feeds both RecordReviewItemFailed and the
		// scan_subtask_error warning, and under --format json the [ocr] progress
		// lines that would say which exit fired are discarded. Name the trigger
		// via the shared Reason() instead of a second hardcoded sentence, so
		// scan and review never describe the same stop differently. The prefix
		// stays for the resume records and warnings that already match on it.
		return false, "main_task did not complete before stopping: " + stop.Reason(), nil
	}
	return true, "", nil
}

// maybeRunPlan invokes PLAN_TASK on the file and returns a human-readable
// guidance string suitable for {{plan_guidance}} substitution. Returns "(no
// pre-scan plan; review the entire file as usual)" when planning is
// disabled or fails — that sentinel is intentionally non-empty so the
// surrounding "### Pre-scan Focus Areas" header in MAIN_TASK has content
// instead of dangling.
func (a *Agent) maybeRunPlan(ctx context.Context, it model.ScanItem, rule string) string {
	const noPlan = "(no pre-scan plan; review the entire file as usual)"

	if !a.planEnabled() {
		return noPlan
	}
	pt := a.args.Template.PlanTask

	// Render plan messages.
	messages := make([]llm.Message, 0, len(pt.Messages))
	for _, m := range pt.Messages {
		content := m.Content
		content = strings.ReplaceAll(content, "{{current_system_date_time}}", a.currentDate)
		content = strings.ReplaceAll(content, "{{current_file_path}}", it.Path)
		content = strings.ReplaceAll(content, "{{system_rule}}", rule)
		content = strings.ReplaceAll(content, "{{file_content}}", it.Content)
		messages = append(messages, llm.NewTextMessage(m.Role, content))
	}

	fs := a.session.GetOrCreateFileSession(it.Path)
	rec := fs.AppendTaskRecord(session.PlanTask, messages)
	ctx = llm.ContextWithSessionKey(ctx,
		llm.SessionTaskKey(a.session.SessionID, string(session.PlanTask), it.Path))
	startTime := time.Now()

	resp, err := a.args.LLMClient.CompletionsWithCtx(ctx, llm.ChatRequest{
		Model:     a.args.Model,
		Messages:  messages,
		MaxTokens: a.args.Template.CompletionTokenLimit(),
	})
	if err != nil {
		rec.SetError(err, time.Since(startTime))
		fmt.Fprintf(stdout.Writer(), "[ocr] scan plan failed for %s: %v (falling back to plan-less)\n", it.Path, err)
		return noPlan
	}
	rec.SetResponse(resp, time.Since(startTime))
	a.runner.RecordUsage(resp.Usage)

	guidance := formatPlanGuidance(resp.Content())
	if guidance == "" {
		return noPlan
	}
	return guidance
}

// maybeRunProjectSummary runs the post-batch PROJECT_SUMMARY_TASK over the
// union of all collected comments. Best-effort: any error / empty input
// / no-template silently leaves projectSummary unset.
func (a *Agent) maybeRunProjectSummary(ctx context.Context, comments []model.LlmComment) {
	if !a.summaryEnabled() {
		return
	}
	pt := a.args.Template.ProjectSummaryTask
	if len(comments) == 0 {
		return
	}

	// Distinct file count for header context.
	fileSet := make(map[string]struct{}, len(comments))
	for _, c := range comments {
		fileSet[c.Path] = struct{}{}
	}
	payload := buildSummaryCommentsList(comments)

	messages := make([]llm.Message, 0, len(pt.Messages))
	for _, m := range pt.Messages {
		content := m.Content
		content = strings.ReplaceAll(content, "{{comment_count}}", fmt.Sprintf("%d", len(comments)))
		content = strings.ReplaceAll(content, "{{file_count}}", fmt.Sprintf("%d", len(fileSet)))
		content = strings.ReplaceAll(content, "{{all_comments}}", payload)
		messages = append(messages, llm.NewTextMessage(m.Role, content))
	}

	const pathKey = "__scan_project_summary__"
	fs := a.session.GetOrCreateFileSession(pathKey)
	rec := fs.AppendTaskRecord(session.MemoryCompressionTask, messages) // reuse existing task type
	ctx = llm.ContextWithSessionKey(ctx,
		llm.SessionTaskKey(a.session.SessionID, string(session.MemoryCompressionTask), pathKey))
	startTime := time.Now()

	resp, err := a.args.LLMClient.CompletionsWithCtx(ctx, llm.ChatRequest{
		Model:     a.args.Model,
		Messages:  messages,
		MaxTokens: a.args.Template.CompletionTokenLimit(),
	})
	if err != nil {
		rec.SetError(err, time.Since(startTime))
		fmt.Fprintf(stdout.Writer(), "[ocr] scan project summary failed: %v\n", err)
		return
	}
	rec.SetResponse(resp, time.Since(startTime))
	a.runner.RecordUsage(resp.Usage)

	body := strings.TrimSpace(llmloop.StripMarkdownFences(resp.Content()))
	if body == "" {
		return
	}
	a.projectSummary = body
}

// buildSummaryCommentsList renders comments as a compact path-anchored
// markdown list suitable for embedding in the PROJECT_SUMMARY_TASK prompt.
// Format: "- `path/to/file.go`: <one-line content (truncated)>".
// Content is truncated to ~280 chars to bound prompt growth on large scans.
func buildSummaryCommentsList(comments []model.LlmComment) string {
	const maxLine = 280
	var sb strings.Builder
	for _, c := range comments {
		sb.WriteString("- `")
		sb.WriteString(c.Path)
		sb.WriteString("`: ")
		oneLine := strings.ReplaceAll(c.Content, "\n", " ")
		if len(oneLine) > maxLine {
			oneLine = oneLine[:maxLine] + "..."
		}
		sb.WriteString(oneLine)
		sb.WriteString("\n")
	}
	return sb.String()
}

// maybeRunDedup, when the template has a DedupTask and the batch produced
// at least DedupMinComments comments, invokes the DEDUP_TASK LLM to merge
// near-duplicate findings. On any failure (LLM error / malformed JSON /
// invalid grouping) the original batch comments are kept unchanged — dedup
// is a best-effort optimization, never a correctness gate. The returned map
// contains safe per-file checkpoints: canonical comments for same-file groups
// and original comments for cross-file groups.
func (a *Agent) maybeRunDedup(ctx context.Context, batchIdx, batchStart int) map[string][]model.LlmComment {
	if !a.dedupEnabled() {
		return nil
	}
	dt := a.args.Template.DedupTask
	minN := a.args.Template.DedupMinComments
	if minN <= 0 {
		minN = 2
	}

	batchComments := a.args.CommentCollector.Since(batchStart)
	if len(batchComments) < minN {
		return nil
	}

	payload := buildDedupCommentsJSON(batchComments)
	messages := make([]llm.Message, 0, len(dt.Messages))
	for _, m := range dt.Messages {
		content := strings.ReplaceAll(m.Content, "{{batch_comments}}", payload)
		messages = append(messages, llm.NewTextMessage(m.Role, content))
	}

	// Use a synthetic file path keyed by batch index so the session JSONL
	// keeps dedup records distinct from per-file plan/main records.
	pathKey := fmt.Sprintf("__scan_dedup_batch_%d__", batchIdx)
	fs := a.session.GetOrCreateFileSession(pathKey)
	rec := fs.AppendTaskRecord(session.MemoryCompressionTask, messages) // reuse existing task type; no scan-specific type to invent
	ctx = llm.ContextWithSessionKey(ctx,
		llm.SessionTaskKey(a.session.SessionID, string(session.MemoryCompressionTask), pathKey))
	startTime := time.Now()

	resp, err := a.args.LLMClient.CompletionsWithCtx(ctx, llm.ChatRequest{
		Model:     a.args.Model,
		Messages:  messages,
		MaxTokens: a.args.Template.CompletionTokenLimit(),
	})
	if err != nil {
		rec.SetError(err, time.Since(startTime))
		fmt.Fprintf(stdout.Writer(), "[ocr] scan dedup failed for batch #%d: %v (keeping originals)\n", batchIdx, err)
		return nil
	}
	rec.SetResponse(resp, time.Since(startTime))
	a.runner.RecordUsage(resp.Usage)

	deduped, dedupCheckpoints, ok := applyDedupGroupsWithCheckpoints(resp.Content(), batchComments)
	if !ok {
		fmt.Fprintf(stdout.Writer(), "[ocr] scan dedup batch #%d: malformed groups, keeping originals\n", batchIdx)
		return nil
	}
	if len(deduped) == len(batchComments) {
		// No-op result — don't bother rewriting the collector.
		return nil
	}
	a.args.CommentCollector.ReplaceSince(batchStart, deduped)
	fmt.Fprintf(stdout.Writer(), "[ocr] scan dedup batch #%d: %d → %d comments\n", batchIdx, len(batchComments), len(deduped))
	return dedupCheckpoints
}

// buildDedupCommentsJSON renders the batch comments as a JSON list with
// stable c-N ids that the LLM groups by. Only fields the LLM needs to
// judge similarity are included (path / content / existing_code), keeping
// the prompt compact.
func buildDedupCommentsJSON(comments []model.LlmComment) string {
	type wire struct {
		ID           string `json:"id"`
		Path         string `json:"path"`
		Content      string `json:"content"`
		ExistingCode string `json:"existing_code,omitempty"`
	}
	items := make([]wire, len(comments))
	for i, cm := range comments {
		items[i] = wire{
			ID:           fmt.Sprintf("c-%d", i),
			Path:         cm.Path,
			Content:      cm.Content,
			ExistingCode: cm.ExistingCode,
		}
	}
	data, _ := json.Marshal(items)
	return string(data)
}

// applyDedupGroups parses the DEDUP_TASK output and returns the deduped
// comment slice. Returns (nil, false) when the response is malformed OR
// when the groups don't cover every input id exactly once (safety: we
// refuse to silently drop comments we can't account for).
func applyDedupGroups(rawJSON string, originals []model.LlmComment) ([]model.LlmComment, bool) {
	comments, _, ok := applyDedupGroupsWithCheckpoints(rawJSON, originals)
	return comments, ok
}

func applyDedupGroupsWithCheckpoints(
	rawJSON string,
	originals []model.LlmComment,
) ([]model.LlmComment, map[string][]model.LlmComment, bool) {
	stripped := llmloop.StripMarkdownFences(rawJSON)
	stripped = strings.TrimSpace(stripped)
	if stripped == "" {
		return nil, nil, false
	}
	var parsed struct {
		Groups []struct {
			Members       []string `json:"members"`
			MergedContent string   `json:"merged_content,omitempty"`
		} `json:"groups"`
	}
	if err := json.Unmarshal([]byte(stripped), &parsed); err != nil {
		return nil, nil, false
	}

	idToIdx := make(map[string]int, len(originals))
	for i := range originals {
		idToIdx[fmt.Sprintf("c-%d", i)] = i
	}

	seen := make(map[string]bool, len(originals))
	var out []model.LlmComment
	checkpoints := make(map[string][]model.LlmComment)
	for _, g := range parsed.Groups {
		if len(g.Members) == 0 {
			return nil, nil, false
		}
		canonicalIdx, ok := idToIdx[g.Members[0]]
		if !ok {
			return nil, nil, false
		}
		memberPaths := make(map[string]bool)
		memberIndices := make([]int, 0, len(g.Members))
		for _, id := range g.Members {
			idx, exists := idToIdx[id]
			if !exists {
				return nil, nil, false // unknown id
			}
			if seen[id] {
				return nil, nil, false // duplicate assignment
			}
			seen[id] = true
			memberPaths[originals[idx].Path] = true
			memberIndices = append(memberIndices, idx)
		}
		canonical := originals[canonicalIdx]
		if len(g.Members) > 1 && g.MergedContent != "" {
			canonical.Content = g.MergedContent
		}
		out = append(out, canonical)
		if len(memberPaths) == 1 {
			checkpoints[canonical.Path] = append(checkpoints[canonical.Path], canonical)
			continue
		}
		for _, idx := range memberIndices {
			original := originals[idx]
			checkpoints[original.Path] = append(checkpoints[original.Path], original)
		}
	}

	if len(seen) != len(originals) {
		return nil, nil, false // some id missing
	}
	return out, checkpoints, true
}

// formatPlanGuidance parses the PLAN_TASK JSON output into a markdown
// snippet suitable for embedding in MAIN_TASK. On parse failure it returns
// the raw content so the model still gets *something* (better than the
// "no plan" fallback when the LLM did say something useful but in the
// wrong shape).
func formatPlanGuidance(raw string) string {
	stripped := llmloop.StripMarkdownFences(raw)
	stripped = strings.TrimSpace(stripped)
	if stripped == "" {
		return ""
	}

	var plan struct {
		Summary     string `json:"summary"`
		Checkpoints []struct {
			Focus string `json:"focus"`
			Lines string `json:"lines,omitempty"`
			Why   string `json:"why,omitempty"`
		} `json:"checkpoints"`
	}
	if err := json.Unmarshal([]byte(stripped), &plan); err != nil {
		// Fallback: hand the raw text to the main task; it's better than
		// nothing and lets us debug bad outputs from session JSONL.
		return stripped
	}

	var sb strings.Builder
	if plan.Summary != "" {
		sb.WriteString("**Summary**: ")
		sb.WriteString(plan.Summary)
		sb.WriteString("\n\n")
	}
	if len(plan.Checkpoints) == 0 {
		// Summary-only plan still has value as orientation.
		return strings.TrimRight(sb.String(), "\n")
	}
	sb.WriteString("**Focus areas (give these extra attention; not exhaustive):**\n")
	for i, cp := range plan.Checkpoints {
		fmt.Fprintf(&sb, "%d. `%s`", i+1, cp.Focus)
		if cp.Lines != "" {
			fmt.Fprintf(&sb, " (lines %s)", cp.Lines)
		}
		if cp.Why != "" {
			fmt.Fprintf(&sb, " — %s", cp.Why)
		}
		sb.WriteString("\n")
	}
	return strings.TrimRight(sb.String(), "\n")
}

// renderMessages substitutes placeholders in the scan template's MainTask
// for a single scan item. planGuidance is the output of maybeRunPlan and
// gets substituted into {{plan_guidance}}; callers should pass a non-empty
// sentinel when planning is disabled so the surrounding section header in
// the prompt template doesn't dangle.
func (a *Agent) renderMessages(it model.ScanItem, rule, planGuidance string) []llm.Message {
	rawMsgs := a.args.Template.MainTask.Messages
	messages := make([]llm.Message, 0, len(rawMsgs))
	for _, m := range rawMsgs {
		content := m.Content
		content = strings.ReplaceAll(content, "{{plan_guidance}}", planGuidance)
		content = strings.ReplaceAll(content, "{{current_system_date_time}}", a.currentDate)
		content = strings.ReplaceAll(content, "{{current_file_path}}", it.Path)
		content = strings.ReplaceAll(content, "{{system_rule}}", rule)
		content = strings.ReplaceAll(content, "{{change_files}}", changeFilesScanLiteral)
		content = strings.ReplaceAll(content, "{{file_content}}", it.Content)
		content = strings.ReplaceAll(content, "{{requirement_background}}", a.args.Background)
		messages = append(messages, llm.NewTextMessage(m.Role, content))
	}
	return messages
}
