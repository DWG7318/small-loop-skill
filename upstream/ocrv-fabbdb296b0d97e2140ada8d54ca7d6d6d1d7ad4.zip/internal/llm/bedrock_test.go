// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 alibaba/open-code-review Contributors

package llm

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// writeConfig writes an OCR config file to a temp dir and returns its path.
func writeConfig(t *testing.T, cfg map[string]any) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "config.json")
	data, err := json.Marshal(cfg)
	if err != nil {
		t.Fatalf("marshal config: %v", err)
	}
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatalf("write config: %v", err)
	}
	return path
}

// TestBedrockProtocolIsRecognized guards the three-part contract documented in
// protocol.go: a new protocol needs a constant, a NormalizeProtocol case, and a
// ValidateProtocol entry. Missing the last one turns a valid config into
// "unsupported protocol".
func TestBedrockProtocolIsRecognized(t *testing.T) {
	for _, raw := range []string{"anthropic-bedrock", "ANTHROPIC-BEDROCK", "  Anthropic-Bedrock  "} {
		if got := NormalizeProtocol(raw); got != ProtocolAnthropicBedrock {
			t.Errorf("NormalizeProtocol(%q) = %q, want %q", raw, got, ProtocolAnthropicBedrock)
		}
	}
	if err := ValidateProtocol(ProtocolAnthropicBedrock); err != nil {
		t.Errorf("ValidateProtocol(%q) = %v, want nil", ProtocolAnthropicBedrock, err)
	}
}

// TestBedrockProviderIsRegistered pins the preset's shape. An api_key or a
// BaseURL here would be wrong: credentials come from the AWS chain and the host
// is derived from the region.
func TestBedrockProviderIsRegistered(t *testing.T) {
	p, ok := LookupProvider("bedrock")
	if !ok {
		t.Fatal("LookupProvider(\"bedrock\") not found")
	}
	if p.Protocol != ProtocolAnthropicBedrock {
		t.Errorf("Protocol = %q, want %q", p.Protocol, ProtocolAnthropicBedrock)
	}
	if !p.AmbientAuth {
		t.Error("AmbientAuth = false, want true — bedrock signs with SigV4 and has no api_key")
	}
	if p.BaseURL != "" {
		t.Errorf("BaseURL = %q, want empty — the region determines the bedrock-runtime host", p.BaseURL)
	}
	if p.EnvVar != "" {
		t.Errorf("EnvVar = %q, want empty — there is no API key env var to fall back to", p.EnvVar)
	}
}

// TestResolveBedrockWithoutAPIKey is the regression test for the two gates that
// rejected a correct Bedrock config: the api_key requirement in
// tryProviderConfig, and the URL-and-Token completeness check in
// ResolveEndpointWithModelOverride. Either one turns a valid setup into
// "no valid LLM endpoint configured", which reads as "you forgot to configure
// anything".
func TestResolveBedrockWithoutAPIKey(t *testing.T) {
	path := writeConfig(t, map[string]any{
		"provider":  "bedrock",
		"model":     "us.anthropic.claude-sonnet-4-6",
		"providers": map[string]any{"bedrock": map[string]any{}},
	})

	ep, err := ResolveEndpoint(path)
	if err != nil {
		t.Fatalf("ResolveEndpoint: %v", err)
	}
	if ep.Protocol != ProtocolAnthropicBedrock {
		t.Errorf("Protocol = %q, want %q", ep.Protocol, ProtocolAnthropicBedrock)
	}
	if !ep.AmbientAuth {
		t.Error("AmbientAuth = false, want true")
	}
	if ep.Token != "" {
		t.Errorf("Token = %q, want empty", ep.Token)
	}
	if ep.Model != "us.anthropic.claude-sonnet-4-6" {
		t.Errorf("Model = %q, want us.anthropic.claude-sonnet-4-6", ep.Model)
	}
}

// TestBedrockDoesNotRunAPIKeyCmd pins that an ambient-auth provider never
// executes api_key_cmd. A signed request has no use for the output, and the
// command is typically a secret-manager read — running it means a real
// 1Password / Touch ID prompt for a value that is immediately discarded. The
// sentinel file proves non-execution; a nil error would not.
func TestBedrockDoesNotRunAPIKeyCmd(t *testing.T) {
	sentinel := filepath.Join(t.TempDir(), "ran")
	path := writeConfig(t, map[string]any{
		"provider": "bedrock",
		"model":    "us.anthropic.claude-sonnet-4-6",
		"providers": map[string]any{
			"bedrock": map[string]any{"api_key_cmd": "touch '" + sentinel + "'; echo sk-should-never-be-used"},
		},
	})

	ep, err := ResolveEndpoint(path)
	if err != nil {
		t.Fatalf("ResolveEndpoint: %v", err)
	}
	if _, err := os.Stat(sentinel); !os.IsNotExist(err) {
		t.Error("api_key_cmd ran for an ambient-auth provider")
	}
	if ep.Token != "" {
		t.Errorf("Token = %q, want empty", ep.Token)
	}
}

// TestResolveBedrockPassesAWSSettings covers aws_profile / aws_region reaching
// the client, so a review run is reproducible without exporting AWS_PROFILE.
func TestResolveBedrockPassesAWSSettings(t *testing.T) {
	// NewLLMClient loads AWS config for the bedrock protocol; point it at empty
	// files so the test does not depend on whatever profiles the developer or
	// the CI runner happens to have.
	t.Setenv("AWS_CONFIG_FILE", filepath.Join(t.TempDir(), "config"))
	t.Setenv("AWS_SHARED_CREDENTIALS_FILE", filepath.Join(t.TempDir(), "credentials"))

	path := writeConfig(t, map[string]any{
		"provider": "bedrock",
		"model":    "us.anthropic.claude-sonnet-4-6",
		"providers": map[string]any{
			"bedrock": map[string]any{"aws_profile": "example-profile", "aws_region": "us-west-2"},
		},
	})

	ep, err := ResolveEndpoint(path)
	if err != nil {
		t.Fatalf("ResolveEndpoint: %v", err)
	}
	if ep.AWSProfile != "example-profile" {
		t.Errorf("AWSProfile = %q, want example-profile", ep.AWSProfile)
	}
	if ep.AWSRegion != "us-west-2" {
		t.Errorf("AWSRegion = %q, want us-west-2", ep.AWSRegion)
	}

	cfg := ClientConfig{}
	if c, ok := NewLLMClient(ep, nil, nil).(*AnthropicClient); ok {
		cfg = c.cfg
	} else {
		t.Fatal("NewLLMClient did not return *AnthropicClient for the bedrock protocol")
	}
	if cfg.AWSProfile != "example-profile" || cfg.AWSRegion != "us-west-2" {
		t.Errorf("ClientConfig AWS settings = %q/%q, want example-profile/us-west-2", cfg.AWSProfile, cfg.AWSRegion)
	}
}

// TestAmbientAuthFollowsTheEffectiveProtocol covers the entry-level protocol
// override. An entry may override a preset's protocol, so reading ambient auth
// off the preset alone lets `protocol: openai` on the bedrock preset resolve with
// no token and no URL — an endpoint that cannot work, reported as if configured.
func TestAmbientAuthFollowsTheEffectiveProtocol(t *testing.T) {
	t.Run("bedrock preset overridden to a token protocol needs a key again", func(t *testing.T) {
		path := writeConfig(t, map[string]any{
			"provider": "bedrock",
			"model":    "gpt-5.4",
			"providers": map[string]any{
				"bedrock": map[string]any{"protocol": "openai", "url": "https://example.invalid/v1"},
			},
		})
		if _, err := ResolveEndpoint(path); err == nil {
			t.Error("resolved with no api_key after the protocol was overridden away from bedrock; want an error")
		}
	})

	t.Run("entry that selects the bedrock protocol signs without a key", func(t *testing.T) {
		path := writeConfig(t, map[string]any{
			"provider": "anthropic",
			"model":    "us.anthropic.claude-sonnet-4-6",
			"providers": map[string]any{
				"anthropic": map[string]any{"protocol": ProtocolAnthropicBedrock},
			},
		})
		t.Setenv("ANTHROPIC_API_KEY", "")
		ep, err := ResolveEndpoint(path)
		if err != nil {
			t.Fatalf("ResolveEndpoint: %v", err)
		}
		if !ep.AmbientAuth {
			t.Error("AmbientAuth = false for an entry whose protocol is anthropic-bedrock")
		}
	})
}

// TestBedrockIsRejectedOnTheURLAndTokenPaths covers the two strategies that
// describe a single HTTP endpoint. Both validated anthropic-bedrock as a
// protocol name and then ignored it — the request would have been signed and
// re-hosted while the url and token the block declares went unused, with no
// region or profile anywhere to state where it went instead.
func TestBedrockIsRejectedOnTheURLAndTokenPaths(t *testing.T) {
	t.Run("OCR_LLM_PROTOCOL", func(t *testing.T) {
		t.Setenv("OCR_LLM_URL", "https://example.invalid/v1")
		t.Setenv("OCR_LLM_TOKEN", "sk-test")
		t.Setenv("OCR_LLM_MODEL", "us.anthropic.claude-sonnet-4-6")
		t.Setenv("OCR_LLM_PROTOCOL", ProtocolAnthropicBedrock)

		_, err := ResolveEndpoint(writeConfig(t, map[string]any{}))
		if err == nil {
			t.Fatal("resolved with OCR_LLM_PROTOCOL=anthropic-bedrock; want an error naming the variable")
		}
		for _, want := range []string{"OCR_LLM_PROTOCOL", "aws_region", `"provider": "bedrock"`} {
			if !strings.Contains(err.Error(), want) {
				t.Errorf("error %q does not mention %q", err, want)
			}
		}
	})

	t.Run("llm.protocol", func(t *testing.T) {
		for _, k := range []string{"OCR_LLM_URL", "OCR_LLM_TOKEN", "OCR_LLM_MODEL", "OCR_LLM_PROTOCOL"} {
			t.Setenv(k, "")
		}
		path := writeConfig(t, map[string]any{
			"llm": map[string]any{
				"url":        "https://example.invalid/v1",
				"auth_token": "sk-test",
				"model":      "us.anthropic.claude-sonnet-4-6",
				"protocol":   ProtocolAnthropicBedrock,
			},
		})

		_, err := ResolveEndpoint(path)
		if err == nil {
			t.Fatal("resolved with llm.protocol=anthropic-bedrock; want an error naming the key")
		}
		if !strings.Contains(err.Error(), "llm.protocol") {
			t.Errorf("error %q does not mention llm.protocol", err)
		}
	})
}

// TestCustomProviderCanSelectBedrock is the other half of that contract: where
// a provider entry exists there is somewhere to put aws_region and aws_profile,
// so bedrock is configurable — and the url every other protocol requires is not
// demanded, because the region decides the host and the client never reads it.
func TestCustomProviderCanSelectBedrock(t *testing.T) {
	t.Run("no url required", func(t *testing.T) {
		path := writeConfig(t, map[string]any{
			"provider": "mine",
			"model":    "us.anthropic.claude-sonnet-4-6",
			"custom_providers": map[string]any{
				"mine": map[string]any{
					"protocol":    ProtocolAnthropicBedrock,
					"aws_region":  "eu-west-1",
					"aws_profile": "example-profile",
				},
			},
		})

		ep, err := ResolveEndpoint(path)
		if err != nil {
			t.Fatalf("ResolveEndpoint: %v", err)
		}
		if !ep.AmbientAuth {
			t.Error("AmbientAuth = false for a custom provider on the bedrock protocol")
		}
		if ep.AWSRegion != "eu-west-1" || ep.AWSProfile != "example-profile" {
			t.Errorf("AWSRegion/AWSProfile = %q/%q, want eu-west-1/example-profile", ep.AWSRegion, ep.AWSProfile)
		}
		if ep.Token != "" {
			t.Errorf("Token = %q, want empty", ep.Token)
		}
	})

	t.Run("url still required for every other protocol", func(t *testing.T) {
		path := writeConfig(t, map[string]any{
			"provider": "mine",
			"model":    "gpt-5.5",
			"custom_providers": map[string]any{
				"mine": map[string]any{"protocol": "openai", "api_key": "sk-test"},
			},
		})

		_, err := ResolveEndpoint(path)
		if err == nil {
			t.Fatal("resolved a custom openai provider with no url; want an error")
		}
		if !strings.Contains(err.Error(), "url") {
			t.Errorf("error %q does not mention the missing url", err)
		}
	})
}

// TestBedrockModelOverrideIsNotGatedByThePresetList covers identifiers scoped
// to an account and region that cannot appear in a list compiled upstream.
func TestBedrockModelOverrideIsNotGatedByThePresetList(t *testing.T) {
	path := writeConfig(t, map[string]any{
		"provider":  "bedrock",
		"model":     "us.anthropic.claude-sonnet-4-6",
		"providers": map[string]any{"bedrock": map[string]any{"aws_region": "us-west-2"}},
	})

	for _, model := range []string{
		"arn:aws:bedrock:us-west-2:123456789012:application-inference-profile/abc123",
		"us.anthropic.claude-haiku-4-5", // a real ID the preset list does not carry
	} {
		ep, err := ResolveEndpointWithModelOverride(path, model)
		if err != nil {
			t.Errorf("ResolveEndpointWithModelOverride(%q) = %v, want it accepted", model, err)
			continue
		}
		if ep.Model != model {
			t.Errorf("resolved model = %q, want %q", ep.Model, model)
		}
	}
}

func TestCustomBedrockModelListDoesNotGateOverride(t *testing.T) {
	path := writeConfig(t, map[string]any{
		"provider": "mine",
		"custom_providers": map[string]any{
			"mine": map[string]any{
				"protocol":   "anthropic-bedrock",
				"aws_region": "us-west-2",
				"models":     []string{"listed-model"},
			},
		},
	})
	var ep ResolvedEndpoint
	var err error
	stderr := captureStderr(t, func() {
		ep, err = ResolveEndpointWithModelOverride(path, "account-specific-model")
	})
	if err != nil || ep.Model != "account-specific-model" || stderr != "" {
		t.Errorf("endpoint = %+v, error = %v, stderr = %q", ep, err, stderr)
	}
}

func TestModelOverrideWarnsForKeyBasedProviders(t *testing.T) {
	path := writeConfig(t, map[string]any{
		"provider":  "anthropic",
		"model":     "claude-sonnet-5",
		"providers": map[string]any{"anthropic": map[string]any{"api_key": "sk-test-not-a-real-key"}},
	})

	var ep ResolvedEndpoint
	var err error
	stderr := captureStderr(t, func() {
		ep, err = ResolveEndpointWithModelOverride(path, "claude-sonnet-5-typo")
	})
	if err != nil || ep.Model != "claude-sonnet-5-typo" || !strings.Contains(stderr, `model "claude-sonnet-5-typo" is not in the suggested models`) {
		t.Errorf("endpoint = %+v, error = %v, stderr = %q", ep, err, stderr)
	}
}

// TestNonAmbientProviderStillRequiresAPIKey makes sure open model lists do not
// relax credential requirements.
func TestNonAmbientProviderStillRequiresAPIKey(t *testing.T) {
	t.Setenv("ANTHROPIC_API_KEY", "")
	path := writeConfig(t, map[string]any{
		"provider":  "anthropic",
		"model":     "claude-opus-4-6",
		"providers": map[string]any{"anthropic": map[string]any{}},
	})

	if _, err := ResolveEndpoint(path); err == nil {
		t.Fatal("ResolveEndpoint succeeded with no api_key for a non-ambient provider; want an error")
	}
}

// TestExplainErrorClassifiesBedrockFailures covers the diagnosis Bedrock's own
// wording does not give. Two of these are actively misleading: the API-key
// complaint names a credential the user cannot configure, and a model absent
// from the region reads as a malformed identifier.
func TestExplainErrorClassifiesBedrockFailures(t *testing.T) {
	// The bearer-token branch consults this variable, so a value in the ambient
	// environment flips the expected message on a developer machine that has one
	// exported. Pin it empty rather than depending on whoever runs the suite.
	t.Setenv("AWS_BEARER_TOKEN_BEDROCK", "")

	client := &AnthropicClient{bedrock: true, awsRegion: "us-west-2", awsProfile: "example-profile"}

	tests := []struct {
		name     string
		err      error
		wantAll  []string
		wantNone []string
	}{
		{
			name:    "bearer token reached the request",
			err:     errors.New(`403 Forbidden {"Message":"Invalid API Key format: Must start with pre-defined prefix"}`),
			wantAll: []string{"no api_key applies to bedrock", "region us-west-2", "profile example-profile"},
		},
		{
			name:    "expired session",
			err:     errors.New("operation error: get credentials: ExpiredToken: the security token included in the request is expired"),
			wantAll: []string{"aws sso login --profile example-profile"},
		},
		{
			// Bedrock answers both "IAM forbids this" and "the account has not
			// enabled this model" with AccessDeniedException, and the fixes have
			// nothing in common. This is the model-access shape, verbatim.
			name:     "model access not enabled for the account",
			err:      errors.New(`operation error Bedrock Runtime: InvokeModel, https response error StatusCode: 403, AccessDeniedException: You don't have access to the model with the specified model ID.`),
			wantAll:  []string{"model access is granted per account and per region", "console"},
			wantNone: []string{"bedrock:InvokeModel"},
		},
		{
			name:     "IAM gap, not a bad credential",
			err:      errors.New("operation error Bedrock Runtime: AccessDeniedException: User: arn:aws:sts::x:assumed-role/y is not authorized to perform: bedrock:InvokeModel"),
			wantAll:  []string{"bedrock:InvokeModel", "authorization gap"},
			wantNone: []string{"sso login"},
		},
		{
			// The same IAM fix reached by different wording, and deliberately
			// without "AccessDenied" in the text: this pins the phrase itself to
			// the authorization branch rather than the exception name.
			name:     "IAM gap phrased as an unauthorized API operation",
			err:      errors.New(`operation error Bedrock Runtime: InvokeModel, https response error StatusCode: 403, Your account is not authorized to invoke this API operation.`),
			wantAll:  []string{"bedrock:InvokeModel", "authorization gap"},
			wantNone: []string{"console"},
		},
		{
			name:    "model absent from the region",
			err:     errors.New("operation error Bedrock Runtime: ValidationException: The provided model identifier is invalid."),
			wantAll: []string{"aws bedrock list-inference-profiles --region us-west-2", "-v1:0"},
		},
		{
			// A request-shape ValidationException is not a model-ID problem, and
			// telling the user to go list inference profiles wastes their time.
			name:     "validation error about the request, not the model",
			err:      errors.New("operation error Bedrock Runtime: ValidationException: Input is too long for requested model."),
			wantAll:  []string{"Input is too long", "region us-west-2"},
			wantNone: []string{"list-inference-profiles", "bedrock:InvokeModel"},
		},
		{
			// A bare "expired" match would claim this is an SSO session problem.
			name:     "expired TLS certificate is not an expired session",
			err:      errors.New(`Post "https://bedrock-runtime.us-west-2.amazonaws.com/v1/messages": tls: failed to verify certificate: x509: certificate has expired or is not yet valid`),
			wantAll:  []string{"certificate has expired"},
			wantNone: []string{"sso login", "credentials are expired"},
		},
		{
			name:     "anything else keeps its own wording and gains context",
			err:      errors.New("connection reset by peer"),
			wantAll:  []string{"connection reset by peer", "region us-west-2"},
			wantNone: []string{"authorization gap", "sso login"},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			got := client.explainError("us.anthropic.claude-sonnet-4-6", tc.err)
			if got == nil {
				t.Fatal("explainError returned nil for a non-nil error")
			}
			if !errors.Is(got, tc.err) {
				t.Error("original error is not wrapped; callers lose the service's own message")
			}
			for _, want := range tc.wantAll {
				if !strings.Contains(got.Error(), want) {
					t.Errorf("message %q does not contain %q", got, want)
				}
			}
			for _, unwanted := range tc.wantNone {
				if strings.Contains(got.Error(), unwanted) {
					t.Errorf("message %q should not mention %q", got, unwanted)
				}
			}
		})
	}
}

// TestExplainErrorNamesTheBearerTokenVariable separates the two ways the same
// 403 arrives: an SSO token the SDK attached on its own, versus a token the user
// set deliberately. The fix differs, so the message has to.
func TestExplainErrorNamesTheBearerTokenVariable(t *testing.T) {
	t.Setenv("AWS_BEARER_TOKEN_BEDROCK", "sk-not-a-real-token")
	client := &AnthropicClient{bedrock: true, awsRegion: "us-west-2"}
	err := client.explainError("m", errors.New(`{"Message":"Invalid API Key format: Must start with pre-defined prefix"}`))
	if !strings.Contains(err.Error(), "AWS_BEARER_TOKEN_BEDROCK") {
		t.Errorf("message %q does not name AWS_BEARER_TOKEN_BEDROCK", err)
	}
}

// TestExplainErrorLeavesNonBedrockErrorsAlone keeps the diagnosis scoped: every
// other protocol shares this client type.
func TestExplainErrorLeavesNonBedrockErrorsAlone(t *testing.T) {
	client := &AnthropicClient{}
	original := errors.New("401 Unauthorized")
	if got := client.explainError("m", original); got != original {
		t.Errorf("explainError rewrote a non-bedrock error: %q", got)
	}
	if got := client.explainError("m", nil); got != nil {
		t.Errorf("explainError(nil) = %v, want nil", got)
	}
}

// TestBedrockContextReportsResolvedRegion covers what `ocr llm test` prints:
// bedrock has no configured URL, so the resolved region is the only way to see
// where a request went.
func TestBedrockContextReportsResolvedRegion(t *testing.T) {
	client := &AnthropicClient{bedrock: true, awsRegion: "us-west-2", awsProfile: "example-profile"}
	region, profile, ok := client.BedrockContext()
	if !ok {
		t.Fatal("ok = false for a bedrock client")
	}
	if region != "us-west-2" || profile != "example-profile" {
		t.Errorf("BedrockContext() = %q/%q, want us-west-2/example-profile", region, profile)
	}

	if _, _, ok := (&AnthropicClient{}).BedrockContext(); ok {
		t.Error("ok = true for a non-bedrock client")
	}
}

// TestBedrockClientReportsAWSFailureAsError is the guard against the SDK's
// bedrock.WithLoadDefaultConfig, which panics when AWS config cannot be loaded.
// A CLI must not hand a user a stack trace because their session expired, so the
// failure is deferred to the first request instead.
func TestBedrockClientReportsAWSFailureAsError(t *testing.T) {
	// An unresolvable profile makes LoadDefaultConfig fail deterministically.
	t.Setenv("AWS_CONFIG_FILE", filepath.Join(t.TempDir(), "nonexistent-config"))
	t.Setenv("AWS_SHARED_CREDENTIALS_FILE", filepath.Join(t.TempDir(), "nonexistent-creds"))

	client := NewAnthropicBedrockClient(ClientConfig{
		Model:      "us.anthropic.claude-sonnet-4-6",
		AWSProfile: "definitely-not-a-real-profile",
	})
	if client == nil {
		t.Fatal("NewAnthropicBedrockClient returned nil; it must always return a client so the error can surface per-request")
	}
	if client.initErr == nil {
		t.Skip("this environment resolved an AWS config for a bogus profile; nothing to assert")
	}
	if _, err := client.CompletionsWithCtx(t.Context(), ChatRequest{}); err == nil {
		t.Error("CompletionsWithCtx returned nil error despite a construction failure")
	}
}
